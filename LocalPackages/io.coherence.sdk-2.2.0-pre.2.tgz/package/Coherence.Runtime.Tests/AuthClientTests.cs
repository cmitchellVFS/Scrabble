// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Runtime.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Coherence.Cloud;
    using Coherence.Tests;
    using Coherence.Utils;
    using Common;
    using NUnit.Framework;
    using UnityEngine;
    using Utils;

    public class AuthClientTests : CoherenceTest
    {
        private const string ProjectId = "ProjectId";
        private CloudUniqueId CloudUniqueId => new("CloudUniqueId");

        private NewPlayerAccountProvider playerAccountProvider;
        private FakeCloudServiceBuilder fakeCloudServiceBuilder;
        private MockRequestFactoryBuilder requestFactory => fakeCloudServiceBuilder.RequestFactoryBuilder;
        private SessionToken ExpectedSessionToken => new(MockRequestFactoryBuilder.DefaultSessionToken);
        private bool SendRequestAsyncWasCalled => requestFactory.SendRequestAsyncWasCalled;
        private (string basePath, string pathParams, string method, string body, Dictionary<string, string> headers, string requestName, string sessionToken) SendRequestAsyncWasCalledWith => requestFactory.SendRequestAsyncWasCalledWith;

        [Test]
        public void LoginWithPassword_Completes_Successfully()
        {
            using var authClient = CreateAuthClient(isReady:true);

            var loginTask = authClient.LoginWithPassword(default, default, default);

            Assert.That(SendRequestAsyncWasCalled, Is.True);
            Assert.That(loginTask.IsCompleted, Is.True);
            Assert.That(loginTask.Result.LoggedIn, Is.True);
        }

        [Test]
        public void LoginWithPassword_Result_Contains_Provided_Username()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string username = "username";
            var loginTask = authClient.LoginWithPassword(username, default, default);

            Assert.That(loginTask.Result.Username, Is.EqualTo(username));
        }

        [TestCase(true), TestCase(false)]
        public void LoginWithPassword_Request_Contains_Provided_Info(bool autoSignup)
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string username = "username";
            const string password = "password";
            _ = authClient.LoginWithPassword(username, password, autoSignup);

            var request = CoherenceJson.DeserializeObject<PasswordLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Password.GetBasePath()));
            Assert.That(request.Username, Is.EqualTo(username));
            Assert.That(request.Password, Is.EqualTo(password));
            Assert.That(request.Autosignup, Is.EqualTo(autoSignup));
        }

        [Test]
        public void LoginAsGuest_Request_Uses_Previously_Saved_GuestId()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string guestId = "guest id";
            GuestId.Save(ProjectId, CloudUniqueId, guestId);
            _ = authClient.LoginAsGuest();

            var request = CoherenceJson.DeserializeObject<GuestLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Guest.GetBasePath()));
            Assert.That(request.GuestId, Is.EqualTo(guestId));

            GuestId.Delete(ProjectId, CloudUniqueId);
        }

        [Test]
        public void LoginWithSteam_Request_Contains_Provided_Info()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string ticket = "ticket";
            const string identity = "identity";
            _ = authClient.LoginWithSteam(ticket, identity);

            var request = CoherenceJson.DeserializeObject<SteamLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Steam.GetBasePath()));
            Assert.That(request.Ticket, Is.EqualTo(ticket));
            Assert.That(request.Identity, Is.EqualTo(identity));
        }

        [Test]
        public void LoginWithPlayStation_Request_Contains_Provided_Info()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string token = "token";
            _ = authClient.LoginWithPlayStation(token);

            var request = CoherenceJson.DeserializeObject<PlayStationLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.PlayStation.GetBasePath()));
            Assert.That(request.Token, Is.EqualTo(token));
        }

        [Test]
        public void LoginWithXbox_Request_Contains_Provided_Info()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string token = "token";
            _ = authClient.LoginWithXbox(token);

            var request = CoherenceJson.DeserializeObject<XboxLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Xbox.GetBasePath()));
            Assert.That(request.Token, Is.EqualTo(token));
        }

        [Test]
        public void LoginWithNintendo_Request_Contains_Provided_Info()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string token = "token";
            _ = authClient.LoginWithNintendo(token);

            var request = CoherenceJson.DeserializeObject<NintendoLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Nintendo.GetBasePath()));
            Assert.That(request.Token, Is.EqualTo(token));
        }

        [Test]
        public void LoginWithJwt_Request_Contains_Provided_Info()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string token = "token";
            _ = authClient.LoginWithJwt(token);

            var request = CoherenceJson.DeserializeObject<JwtLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Jwt.GetBasePath()));
            Assert.That(request.Token, Is.EqualTo(token));
        }

        [Test]
        public void LoginWithOneTimeCode_Request_Contains_Provided_Info()
        {
            using var authClient = CreateAuthClient(isReady:true);

            const string code = "code";
            _ = authClient.LoginWithOneTimeCode(code);

            var request = CoherenceJson.DeserializeObject<OneTimeCodeLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(requestFactory.SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.OneTimeCode.GetBasePath()));
            Assert.That(request.Code, Is.EqualTo(code));
        }

        [Test]
        public void LoginAsGuest_Completes_Successfully()
        {
            using var authClient = CreateAuthClient(isReady:true);

            var loginTask = authClient.LoginAsGuest();

            Assert.That(SendRequestAsyncWasCalled, Is.True);
            Assert.That(loginTask.IsCompleted, Is.True);
            Assert.That(loginTask.Result.LoggedIn, Is.True);
        }

        [Test]
        public void LogsOut_After_Websocket_Disconnected() => Assert.Ignore("Not implemented yet.");

        [Test]
        public void GeneratesNewLegacyGuestAccount_When_Fresh_LoggingInAsGuest()
        {
            const string legacyUsername = "testUsername";
            const string legacyPassword = "testPassword";
            const string guestId = "testGuestId";
            LegacyLoginData.SetCredentials(ProjectId, CloudUniqueId, legacyUsername, legacyPassword);
            LegacyLoginData.Clear(ProjectId, CloudUniqueId);
            GuestId.Save(ProjectId, CloudUniqueId, guestId);
            GuestId.Delete(ProjectId, CloudUniqueId);

            using var authClient = CreateAuthClient(autoLoginAsGuest: true);

            var request = CoherenceJson.DeserializeObject<PasswordLoginRequest>(requestFactory.SendRequestAsyncWasCalledWith.body);

            Assert.That(authClient.LoggedIn, Is.True);
            Assert.That(request.Username, Is.Not.EqualTo(legacyUsername));
            Assert.That(request.Password, Is.Not.EqualTo(legacyPassword));
            Assert.That(GuestId.GetOrCreate(ProjectId, CloudUniqueId), Is.Not.EqualTo(guestId));
        }

        [Test]
        public void Should_AutoLoginAsGuest_When_Instantiating()
        {
            using var authClient = CreateAuthClient(autoLoginAsGuest: true);

            Assert.That(GetSessionToken(authClient), Is.EqualTo(ExpectedSessionToken));
            Assert.That(authClient.LoggedIn, Is.True);
        }

        [Test]
        public void Should_AutoConnect_When_Using_AutoLoginAsGuest()
        {
            using var authClient = CreateAuthClient(autoLoginAsGuest:true);

            Assert.That(GetSessionToken(authClient), Is.EqualTo(ExpectedSessionToken));
            Assert.That(authClient.LoggedIn, Is.True);
        }

        [Test]
        public void Should_CallAccountEndpoint_When_InstantiatingWithAutoLoginAsGuestAndRequestBuilderIsReady()
        {
            using var authClient = CreateAuthClient(autoLoginAsGuest:true, isReady:true);

            Assert.That(SendRequestAsyncWasCalled, Is.True);
            Assert.That(SendRequestAsyncWasCalledWith.basePath, Is.EqualTo(LoginType.Guest.GetBasePath()));
            Assert.That(SendRequestAsyncWasCalledWith.method, Is.EqualTo(AuthClient.LoginRequestMethod));
            Assert.That(SendRequestAsyncWasCalledWith.requestName, Is.EqualTo(AuthClient.LoginRequestName));
            Assert.That(SendRequestAsyncWasCalledWith.sessionToken, Is.Null.Or.Empty);
        }

        [Test]
        public void Should_RefreshLogin_When_InstantiatingWithCachedToken()
        {
            using var authClient = CreateAuthClient(autoLoginAsGuest:false, isReady:true);
            var expectedSessionToken = new SessionToken("ExpectedSessionToken");

            var result = authClient.LoginWithSessionToken(expectedSessionToken);

            Assert.That(result.IsCompleted, Is.True);
            Assert.That(result.Result.LoggedIn, Is.True);
            Assert.That(result.Result.SessionToken, Is.EqualTo(ExpectedSessionToken));
            Assert.That(GetSessionToken(authClient), Is.EqualTo(ExpectedSessionToken));
            Assert.That(authClient.LoggedIn, Is.True);
        }

        [Test]
        public void Dispose_Does_Not_Cause_Warnings_Or_Errors()
        {
            var authClient = CreateAuthClient(autoLoginAsGuest:false, isReady:true);
            (string condition, string stacktrace, LogType type)? loggedWarningOrError = null;
            Application.logMessageReceived += OnLogMessageReceived;
            try
            {
                authClient.Dispose();
            }
            finally
            {
                Application.logMessageReceived -= OnLogMessageReceived;
            }

            if (loggedWarningOrError is not null)
            {
                var (condition, stacktrace, type) = loggedWarningOrError.Value;
                Assert.Fail($"Unexpected message of type {type}: {condition}\n{stacktrace}");
            }

            void OnLogMessageReceived(string condition, string stacktrace, LogType type)
            {
                if (type is not LogType.Log)
                {
                    loggedWarningOrError = (condition, stacktrace, type);
                    Application.logMessageReceived -= OnLogMessageReceived;
                }
            }
        }

        [TestCase(false, false, false, false)]
        [TestCase(false, false, true, false)]
        [TestCase(false, true, false, false)]
        [TestCase(false, true, true, false)]
        [TestCase(true, false, false, false)]
        [TestCase(true, false, true, false)]
        [TestCase(true, true, false, false)]
        [TestCase(true, true, true, false)]
        [TestCase(false, false, false, true)]
        [TestCase(false, false, true, true)]
        [TestCase(false, true, false, true)]
        [TestCase(false, true, true, true)]
        [TestCase(true, false, false, true)]
        [TestCase(true, false, true, true)]
        [TestCase(true, true, false, true)]
        [TestCase(true, true, true, true)]
        public async Task Dispose_Does_Not_Cause_Warnings_Or_Errors_If_Login_Is_In_Progress(bool isReady, bool cancelLogin, bool shouldYield, bool delay)
        {
            if (delay)
            {
                requestFactory.SetConnectDelay(0.1f);
            }

            var authClient = CreateAuthClient(autoLoginAsGuest:false, isReady:isReady);
            (string condition, string stacktrace, LogType type)? loggedWarningOrError = null;
            var cancellationTokenSource = new CancellationTokenSource();
            var loginTask = authClient.LoginAsGuest(cancellationTokenSource.Token);
            Application.logMessageReceived += OnLogMessageReceived;

            if (shouldYield)
            {
                await Task.Yield();
            }

            if (cancelLogin)
            {
                cancellationTokenSource.Cancel();
            }

            try
            {
                authClient.Dispose();
            }
            finally
            {
                Application.logMessageReceived -= OnLogMessageReceived;
            }

            try
            {
                await loginTask;
            }
            catch (TaskCanceledException)
            {
                // Expected exception
            }

            if (loggedWarningOrError is not null)
            {
                var (condition, stacktrace, type) = loggedWarningOrError.Value;
                Assert.Fail($"Unexpected message of type {type}: {condition}\n{stacktrace}");
            }

            void OnLogMessageReceived(string condition, string stacktrace, LogType type)
            {
                if (type is not LogType.Log)
                {
                    loggedWarningOrError = (condition, stacktrace, type);
                    Application.logMessageReceived -= OnLogMessageReceived;
                }
            }
        }

        [Test]
        public void Login_Operation_Fails_On_WebSocket_Disconnect()
        {
            requestFactory.SetCanConnectWebSocket(false);
            using var authClient = CreateAuthClient(isReady: false);

            var loginTask = authClient.LoginAsGuest();
            requestFactory.RaiseOnWebSocketDisconnect();
            Assert.That(loginTask.IsCompleted, Is.True);
            Assert.That(loginTask.IsFaulted, Is.False);
            Assert.That(loginTask.Result.Type, Is.EqualTo(Result.ConnectionError));
            Assert.That(loginTask.Result.Error, Is.Not.Null);
            Assert.That(loginTask.Result.LoggedIn, Is.False);
        }

        [Test]
        public async Task Login_Operation_Fails_If_WebSocket_Fails_To_Connect_Within_Time_Out()
        {
            requestFactory.SetConnectDelay(1f);
            using var authClient = CreateAuthClient(isReady: false);
            authClient.ConnectTimeoutAfterSeconds = 0.1f;

            var loginTask = authClient.LoginAsGuest();
            await loginTask;

            Assert.That(loginTask.IsCompleted, Is.True);
            Assert.That(loginTask.IsFaulted, Is.False);
            Assert.That(loginTask.Result.Type, Is.EqualTo(Result.ConnectionError));
            Assert.That(loginTask.Result.Error, Is.Not.Null);
            Assert.That(loginTask.Result.LoggedIn, Is.False);
        }

        [Test]
        public async Task Time_Out_Timer_Running_Out_Has_No_Effect_If_Operation_Has_Already_Completed()
        {
            requestFactory.SetConnectDelay(0.1f);
            using var authClient = CreateAuthClient(isReady: true);
            authClient.ConnectTimeoutAfterSeconds = 0.2f;

            var loginTask = authClient.LoginAsGuest();
            await loginTask;
            await TimeSpan.FromSeconds(0.2f);

            Assert.That(loginTask.IsCompletedSuccessfully, Is.True);
        }

        [Test]
        public async Task Login_Operation_Can_Be_Canceled()
        {
            requestFactory.SetConnectDelay(0.1f);
            using var authClient = CreateAuthClient(isReady: false);
            var cancellationTokenSource = new CancellationTokenSource();
            var loginTask = authClient.LoginAsGuest(cancellationTokenSource.Token);
            cancellationTokenSource.Cancel();
            try
            {
                await loginTask;
            }
            catch (TaskCanceledException)
            {
                // Expected exception.
                return;
            }
            catch (Exception exception)
            {
                Assert.Fail($"Expected LoginAsGuest task to fail with a TaskCanceledException. Instead it failed with a {exception.GetType().Name}: {exception}.");
                return;
            }

            Assert.Fail($"Expected LoginAsGuest task to fail with a TaskCanceledException. Instead the task completed with the result {loginTask.Result.Type}.");
        }

        [SetUp]
        public override void SetUp()
        {
            fakeCloudServiceBuilder = new();
            playerAccountProvider = new(fakeCloudServiceBuilder.Build, ProjectId, CloudUniqueId);
            fakeCloudServiceBuilder
                .SetProjectId(ProjectId)
                .SetUniqueId(CloudUniqueId)
                .SetPlayerAccountProvider(playerAccountProvider)
                .SetupRequestFactory(requestFactory => requestFactory
                    .SetSessionToken(ExpectedSessionToken)
                    .SetIsReady());

            base.SetUp();
        }

        [TearDown]
        public override void TearDown()
        {
            playerAccountProvider.Dispose();
            fakeCloudServiceBuilder.Dispose();

            foreach (var playerAccount in PlayerAccount.All)
            {
                Log.Log.GetLogger<AuthClientTests>().Error(Log.Error.UnitTestMissingCleanUp, $"Test did not unregister player account: {playerAccount}.");
                PlayerAccount.Unregister(playerAccount);
            }

            base.TearDown();
        }

        private AuthClient CreateAuthClient(bool autoLoginAsGuest = false, bool isReady = false)
        {
            requestFactory.SetIsReady(isReady);
            AuthClient result = null;
            fakeCloudServiceBuilder.SetAuthClient(()=> result);
            result = AuthClient.ForPlayer(requestFactory.Build(), playerAccountProvider);

            if (autoLoginAsGuest)
            {
                result.LoginAsGuest().Then(task => Assert.Fail(task.Exception.ToString()), TaskContinuationOptions.OnlyOnFaulted);
            }

            return result;
        }

        [Test]
        public async Task Logout_Sets_PlayerAccount_To_Null()
        {
            var authClient = CreateAuthClient(isReady: true);

            var loginResult = await authClient.LoginAsGuest();
            var playerAccount = loginResult.PlayerAccount;
            Assert.That(playerAccount, Is.Not.Null);

            authClient.Logout();

            Assert.That(authClient.PlayerAccount, Is.Null, "Expected AuthClient.PlayerAccount to be null after AuthClient.Logout has been executed.");
        }

        [Test]
        public async Task Logout_Causes_PlayerAccount_IsLoggedIn_To_Become_False()
        {
            using var authClient = CreateAuthClient(isReady: true);

            var loginResult = await authClient.LoginAsGuest();
            var playerAccount = loginResult.PlayerAccount;
            Assert.That(playerAccount.IsLoggedIn, Is.True, "Expected PlayerAccount.IsLoggedIn to be true after AuthClient.LoginAsGuest completed successfully.");

            authClient.Logout();

            Assert.That(playerAccount.IsLoggedIn, Is.False, "Expected PlayerAccount.IsLoggedIn to be false after AuthClient.Logout has been executed.");
        }

        [Test]
        public async Task PlayerAccounts_Are_Disposed_Properly()
        {
            var authClient = CreateAuthClient(isReady: true);

            var loginResult = await authClient.LoginAsGuest();
            var playerAccount1 = loginResult.PlayerAccount;
            var playerAccount1OnDisposedRaisedTimes = 0;
            playerAccount1.OnDisposed += () => playerAccount1OnDisposedRaisedTimes += 1;

            authClient.Logout();

            var loginResult2 = await authClient.LoginAsGuest();
            var playerAccount2 = loginResult2.PlayerAccount;
            var playerAccount2OnDisposedRaisedTimes = 0;
            playerAccount2.OnDisposed += () => playerAccount2OnDisposedRaisedTimes += 1;

            authClient.Logout();

            var loginResult3 = await authClient.Login(LoginInfo.ForGuest(GuestId.GetOrCreate(playerAccountProvider.ProjectId, "Guest3")));
            var playerAccount3 = loginResult3.PlayerAccount;
            var playerAccount3OnDisposedRaisedTimes = 0;
            playerAccount3.OnDisposed += () => playerAccount3OnDisposedRaisedTimes += 1;

            authClient.Dispose();
            playerAccountProvider.Dispose();

            Assert.That(playerAccount1OnDisposedRaisedTimes, Is.EqualTo(1), "Expected playerAccount1.OnDisposed to have been raised after AuthClient and NewPlayerAccountProvider have been disposed.");
            Assert.That(playerAccount2OnDisposedRaisedTimes, Is.EqualTo(1), "Expected playerAccount2.OnDisposed to have been raised after AuthClient and NewPlayerAccountProvider have been disposed.");
            Assert.That(playerAccount3OnDisposedRaisedTimes, Is.EqualTo(1), "Expected playerAccount3.OnDisposed to have been raised after AuthClient and NewPlayerAccountProvider have been disposed.");

            Assert.That(playerAccount1.OwnerCount, Is.EqualTo(0), "Expected playerAccount1.OwnerCount to be 0 after AuthClient and NewPlayerAccountProvider have been disposed.");
            Assert.That(playerAccount2.OwnerCount, Is.EqualTo(0), "Expected playerAccount2.OwnerCount to be 0 after AuthClient and NewPlayerAccountProvider have been disposed.");
            Assert.That(playerAccount3.OwnerCount, Is.EqualTo(0), "Expected playerAccount3.OwnerCount to be 0 after AuthClient and NewPlayerAccountProvider have been disposed.");

            Assert.That(playerAccount1.IsLoggedIn, Is.False, "Expected playerAccount1.IsLoggedIn to be false after AuthClient.Logout has been executed.");
            Assert.That(playerAccount2.IsLoggedIn, Is.False, "Expected playerAccount2.IsLoggedIn to be false after AuthClient.Logout has been executed.");
            Assert.That(playerAccount3.IsLoggedIn, Is.False, "Expected playerAccount3.IsLoggedIn to be false after AuthClient and NewPlayerAccountProvider have been disposed.");
        }

        private static SessionToken GetSessionToken(AuthClient authClient) => ((IAuthClientInternal)authClient).SessionToken;
    }
}
