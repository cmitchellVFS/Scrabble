// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Runtime.Tests
{
    using System.Net;
    using Coherence.Tests;
    using Log;
    using NUnit.Framework;
    using Result = UnityEngine.Networking.UnityWebRequest.Result;

    /// <summary>
    /// Edit mode unit tests for <see cref="RequestException"/>.
    /// </summary>
    public class RequestExceptionTests : CoherenceTest
    {
        [TestCase(null, default(HttpStatusCode), null)]
        [TestCase(null, default(HttpStatusCode), "")]
        [TestCase("", default(HttpStatusCode), null)]
        [TestCase("", default(HttpStatusCode), "")]
        [TestCase(null, HttpStatusCode.ServiceUnavailable, null)]
        [TestCase("Response", HttpStatusCode.ServiceUnavailable, "Error")]
        public void TryParse_Succeeds_For_ConnectionError_Result(string response, HttpStatusCode responseCode, string error)
        {
            var success = RequestException.TryParse(Result.ConnectionError, response, (int)responseCode, error, out var exception, logger);

            Assert.That(success, Is.True);
            Assert.That(exception, Is.Not.Null);
            Assert.That(exception.HttpStatusCode, Is.EqualTo(responseCode));
            Assert.That(logger.GetCountForWarningID(Warning.RuntimeRequestResponse), Is.EqualTo(string.IsNullOrEmpty(response) ? 0 : 1));
        }

        [TestCase(null, default(HttpStatusCode), null)]
        [TestCase(null, default(HttpStatusCode), "")]
        [TestCase("", default(HttpStatusCode), null)]
        [TestCase("", default(HttpStatusCode), "")]
        [TestCase(null, HttpStatusCode.ServiceUnavailable, null)]
        [TestCase("Response", HttpStatusCode.ServiceUnavailable, "Error")]
        public void TryParse_Succeeds_For_DataProcessingError_Result(string response, HttpStatusCode responseCode, string error)
        {
            var success = RequestException.TryParse(Result.DataProcessingError, response, (int)responseCode, error, out var exception, logger);

            Assert.That(success, Is.True);
            Assert.That(exception, Is.Not.Null);
            Assert.That(exception.HttpStatusCode, Is.EqualTo(responseCode));
            Assert.That(logger.GetCountForWarningID(Warning.RuntimeRequestResponse), Is.EqualTo(string.IsNullOrEmpty(response) ? 0 : 1));
        }

        [TestCase(null, default(HttpStatusCode), null)]
        [TestCase(null, default(HttpStatusCode), "")]
        [TestCase("", default(HttpStatusCode), null)]
        [TestCase("", default(HttpStatusCode), "")]
        [TestCase(null, HttpStatusCode.ServiceUnavailable, null)]
        [TestCase("Response", HttpStatusCode.ServiceUnavailable, "Error")]
        public void TryParse_Succeeds_For_ProtocolError_Result(string response, HttpStatusCode responseCode, string error)
        {
            var success = RequestException.TryParse(Result.ProtocolError, response, (int)responseCode, error, out var exception, logger);

            Assert.That(success, Is.True);
            Assert.That(exception, Is.Not.Null);
            Assert.That(exception.HttpStatusCode, Is.EqualTo(responseCode));
            Assert.That(logger.GetCountForWarningID(Warning.RuntimeRequestResponse), Is.EqualTo(string.IsNullOrEmpty(response) ? 0 : 1));
        }

        [TestCase(null, default(HttpStatusCode), null)]
        [TestCase(null, default(HttpStatusCode), "")]
        [TestCase("", default(HttpStatusCode), null)]
        [TestCase("", default(HttpStatusCode), "")]
        [TestCase(null, HttpStatusCode.ServiceUnavailable, null)]
        [TestCase("Response", HttpStatusCode.ServiceUnavailable, "Error")]
        public void TryParse_Fails_For_Sucess_Result(string response, HttpStatusCode responseCode, string error)
        {
            var success = RequestException.TryParse(Result.Success, response, (int)responseCode, error, out var exception, logger);

            Assert.That(success, Is.False);
            Assert.That(exception, Is.Null);
        }

        [TestCase(null, default(HttpStatusCode), null)]
        [TestCase(null, default(HttpStatusCode), "")]
        [TestCase("", default(HttpStatusCode), null)]
        [TestCase("", default(HttpStatusCode), "")]
        [TestCase(null, HttpStatusCode.ServiceUnavailable, null)]
        [TestCase("Response", HttpStatusCode.ServiceUnavailable, "Error")]
        public void TryParse_Fails_For_InProgress_Result(string response, HttpStatusCode responseCode, string error)
        {
            var success = RequestException.TryParse(Result.InProgress, response, (int)responseCode, error, out var exception, logger);

            Assert.That(success, Is.False);
            Assert.That(exception, Is.Null);
        }

        [TestCase(null, default(HttpStatusCode), null)]
        [TestCase(null, default(HttpStatusCode), "")]
        [TestCase("", default(HttpStatusCode), null)]
        [TestCase("", default(HttpStatusCode), "")]
        [TestCase(null, HttpStatusCode.ServiceUnavailable, null)]
        [TestCase("Response", HttpStatusCode.ServiceUnavailable, "Error")]
        public void TryParse_Fails_For_Unnamed_Result(string response, HttpStatusCode responseCode, string error)
        {
            var success = RequestException.TryParse((Result)(-100), response, (int)responseCode, error, out var exception, logger);

            Assert.That(success, Is.False);
            Assert.That(exception, Is.Null);
        }

        [Test]
        public void TryParse_RSBadRequest_Returns_Exception_With_ErrorCode_And_Id()
        {
            var response = "{\"id\":\"68159a30:5;0\",\"error_code\":\"ERR_RS_BAD_REQUEST\",\"timeout\":false,\"fault\":false,\"temporary\":false}";

            var success = RequestException.TryParse(Result.ProtocolError, response, (int)HttpStatusCode.BadRequest, null, out var exception, logger);

            Assert.That(success, Is.True);
            Assert.That(exception, Is.Not.Null);
            Assert.That(exception.RequestId, Is.EqualTo("68159a30:5;0"));
            Assert.That(exception.Message, Does.Contain("68159a30:5;0"));
            Assert.That(exception.ErrorCode, Is.EqualTo(ErrorCode.RSBadRequest));
        }

        [Test]
        public void TryParse_RequireCreditCard_Returns_Exception_With_ErrorCode_And_Actionable_Message()
        {
            // Wire payload returned by the portal when a payment method is required (e.g. uploading a simulator).
            const string response = "{\"id\":\"b15be68c:6\",\"error_code\":\"REQUIRE_CREDIT_CARD\",\"timeout\":false,\"fault\":false,\"temporary\":false}";

            var success = RequestException.TryParse(Result.ProtocolError, response, (int)HttpStatusCode.BadRequest, null, out var exception, logger);

            Assert.That(success, Is.True);
            Assert.That(exception, Is.Not.Null);
            Assert.That(exception.ErrorCode, Is.EqualTo(ErrorCode.RequireCreditCard));
            Assert.That(exception.RequestId, Is.EqualTo("b15be68c:6"));
            Assert.That(exception.Message, Does.Contain("payment method"));
        }
    }
}
