// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Runtime.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Coherence.Cloud;
    using Common;
    using Moq;
    using NUnit.Framework;
    using Coherence.Tests;

    public class CloudRoomsServiceTests : CoherenceTest
    {
        private Mock<IAuthClientInternal> authClient = new();
        private Mock<IRuntimeSettings> runtimeSettings = new();

        private string roomsResponse =
            "{\"rooms\":[{\"room_id\":1,\"unique_id\":1766322077975,\"sdk_version\":\"v0.10.9\",\"host\":{\"ip\":\"18.196.114.164\",\"port\":31057,\"region\":\"eu\",\"rs_version\":\"v0.46.3\"},\"tags\":[],\"kv\":{\"name\":\"Room1\"},\"max_players\":10,\"connected_players\":0,\"sim_slug\":\"\"},{\"room_id\":3,\"unique_id\":1766338855191,\"sdk_version\":\"v0.10.9\",\"host\":{\"ip\":\"18.196.114.164\",\"port\":31057,\"region\":\"eu\",\"rs_version\":\"v0.46.3\"},\"tags\":[],\"kv\":{\"name\":\"Room2\"},\"max_players\":10,\"connected_players\":0,\"sim_slug\":\"\"}]}";

        private string emptyResponse = "{\"rooms\":[]}";

        private string createRoomResponse =
            "{\"delete_room_token\":\"70ef923f\",\"room_id\":4,\"unique_id\":1766422741271,\"sdk_version\":\"v0.10.9\",\"host\":{\"ip\":\"18.196.114.164\",\"port\":31057,\"region\":\"eu\",\"rs_version\":\"v0.46.3\"},\"tags\":[],\"kv\":{\"name\":\"\"},\"max_players\":10,\"connected_players\":0,\"sim_slug\":\"\",\"secret\":\"70ef923f\"}";

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();

            runtimeSettings.Setup(settings => settings.SchemaID).Returns(string.Empty);
            runtimeSettings.Setup(settings => settings.RsVersion).Returns(string.Empty);
            runtimeSettings.Setup(settings => settings.SimulatorSlug).Returns(string.Empty);
            authClient.SetupGet(ac => ac.SessionToken).Returns(SessionToken.None);
        }

        private static void SetupRequestCallback(Mock<IRequestFactoryInternal> requestMock,
            Action<string, string, string, string, Dictionary<string, string>, string, string,
                Action<RequestResponse<string>>, bool> callback)
        {
            requestMock.Setup(factory => factory.SendRequest(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Action<RequestResponse<string>>>(),
                    It.IsAny<bool>()))
                .Callback(callback);
        }

        private static void SetupRequestAsyncCallback(Mock<IRequestFactoryInternal> requestMock,
            Action<string, string, string, string, Dictionary<string, string>, string, string, bool> callback)
        {
            requestMock.Setup(factory => factory.SendRequestAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()))
                .Callback(callback);
        }

        private static void SetupRequestAsyncReturns(Mock<IRequestFactoryInternal> requestMock,
            Func<string, string, string, string, Dictionary<string, string>, string, string, bool, Task<string>> callback)
        {
            requestMock.Setup(factory => factory.SendRequestAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()))
                .Returns(callback);
        }

        [Test]
        public void Should_ReturnNoRooms_When_NoRoomsExist()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            SetupRequestCallback(requestMock, (_, _, _, _, _, _, _, cb, _) =>
            {
                var response = new RequestResponse<string>
                {
                    Result = emptyResponse,
                    Status = RequestStatus.Success,
                };

                cb.Invoke(response);
            });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("foo", credentials, runtimeSettings.Object);

            var receivedRooms = false;

            roomsService.FetchRooms(list =>
            {
                if (list.Result.Count == 0)
                {
                    receivedRooms = true;
                }
            });

            Assert.IsTrue(receivedRooms);
        }

        [Test]
        public void Should_ReturnTwoRooms_When_TwoRoomsExist()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            SetupRequestCallback(requestMock, (_, _, _, _, _, _, _, cb, _) =>
            {
                var response = new RequestResponse<string>
                {
                    Result = roomsResponse,
                    Status = RequestStatus.Success,
                };

                cb.Invoke(response);
            });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var receivedRooms = false;

            roomsService.FetchRooms(list =>
            {
                if (list.Result.Count == 2)
                {
                    receivedRooms = true;
                }
            });

            Assert.IsTrue(receivedRooms);
        }

        [Test]
        public void Should_RethrowException_When_RequestHasException()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            SetupRequestCallback(requestMock, (_, _, _, _, _, _, _, cb, _) =>
            {
                var response = new RequestResponse<string>
                {
                    Exception = new RequestException(ErrorCode.Unknown),
                    Status = RequestStatus.Fail,
                };

                cb.Invoke(response);
            });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var caughtException = false;

            roomsService.FetchRooms(list =>
            {
                caughtException = list.Exception != null;
            });

            Assert.IsTrue(caughtException);
        }

        [Test]
        public async Task Should_ReturnTwoRooms_When_TwoRoomsExistAsync()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);
            SetupRequestAsyncReturns(requestMock, (_, _, _, _, _, _, _, _) => Task.FromResult(roomsResponse));

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var response = await roomsService.FetchRoomsAsync();

            Assert.IsTrue(response.Count == 2);
        }

        [Test]
        public async Task Should_ReturnNoRooms_When_NoRoomsExistAsync()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);
            SetupRequestAsyncReturns(requestMock, (_, _, _, _, _, _, _, _) => Task.FromResult(emptyResponse));

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var response = await roomsService.FetchRoomsAsync();

            Assert.IsTrue(response.Count == 0);
        }

        [Test]
        [Description("Regression test for #9801: FetchRoomsAsync must not throw when SimulatorSlug is null, omitting the sim_slug query parameter like the synchronous overload.")]
        public async Task Should_OmitSimSlug_When_SimulatorSlugIsNullAsync()
        {
            runtimeSettings.Setup(settings => settings.SimulatorSlug).Returns((string)null);

            string capturedPathParams = null;
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);
            SetupRequestAsyncReturns(requestMock, (_, pathParams, _, _, _, _, _, _) =>
            {
                capturedPathParams = pathParams;
                return Task.FromResult(emptyResponse);
            });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var response = await roomsService.FetchRoomsAsync();

            Assert.That(response.Count, Is.EqualTo(0));
            Assert.That(capturedPathParams, Does.Not.Contain("sim_slug"));
        }

        [Test]
        public async Task Should_RethrowException_When_RequestHasExceptionAsync()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);
            SetupRequestAsyncCallback(requestMock,
                (_, _, _, _, _, _, _, _) => throw new RequestException(ErrorCode.Unknown));

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var caughtException = false;

            try
            {
                var task = roomsService.FetchRoomsAsync();

                await task;
            }
#pragma warning disable 0168
            catch (RequestException e)
#pragma warning restore 0168
            {
                caughtException = true;
            }
            finally
            {
                Assert.IsTrue(caughtException);
            }
        }

        [Test]
        public async Task Should_QueueCallbacks_When_RequestIsOnGoing()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            var callbackSignal = new TaskCompletionSource<bool>();
            SetupRequestCallback(requestMock, async (_, _, _, _, _, _, _, cb, _) =>
            {
                var response = new RequestResponse<string>
                {
                    Result = roomsResponse,
                    Status = RequestStatus.Success,
                };

                await callbackSignal.Task;

                cb.Invoke(response);
            });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var receivedRooms1 = false;
            roomsService.FetchRooms(list =>
            {
                receivedRooms1 = true;
            });

            // The callback should NOT been called yet as callbackSignal is still blocking
            Assert.IsFalse(receivedRooms1);

            // Remove the block from the response
            SetupRequestCallback(requestMock, (_, _, _, _, _, _, _, cb, _) =>
            {
                var response = new RequestResponse<string>
                {
                    Result = roomsResponse,
                    Status = RequestStatus.Success,
                };

                cb.Invoke(response);
            });

            // While the response doesn't block, the queue should
            var receivedRooms2 = false;
            roomsService.FetchRooms(list =>
            {
                receivedRooms2 = true;
            });

            Assert.IsFalse(receivedRooms2);

            // Unblock queue
            callbackSignal.SetResult(true);
            await callbackSignal.Task;

            // Callback queue should be processed
            Assert.IsTrue(receivedRooms1);
            Assert.IsTrue(receivedRooms2);
        }

        [Test]
        public void Should_CreateOneRoom_When_CreatingARoom()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(factory => factory.SendRequest(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Action<RequestResponse<string>>>(),
                    It.IsAny<bool>()))
                .Callback<string, string, string, Dictionary<string, string>, string, string,
                    Action<RequestResponse<string>>, bool>(
                    (_, _, _, _, _, _, cb, _) =>
                    {
                        var response = new RequestResponse<string>
                        {
                            Result = createRoomResponse,
                            Status = RequestStatus.Success,
                        };

                        cb.Invoke(response);
                    });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            RoomData roomCreated = default;

            roomsService.CreateRoom(room =>
            {
                roomCreated = room.Result;
            }, RoomCreationOptions.Default);

            var hasRoom = false;

            foreach (var room in roomsService.CachedRooms)
            {
                if (room.UniqueId == roomCreated.UniqueId)
                {
                    hasRoom = true;
                }
            }

            Assert.IsTrue(hasRoom);
        }

        [Test]
        public async Task Should_CreateOneRoom_When_CreatingARoomAsync()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);
            requestMock.Setup(factory => factory.SendRequestAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()))
                .Returns(Task.FromResult(createRoomResponse));

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var roomCreated = await roomsService.CreateRoomAsync(RoomCreationOptions.Default);

            var hasRoom = false;

            foreach (var room in roomsService.CachedRooms)
            {
                if (room.UniqueId == roomCreated.UniqueId)
                {
                    hasRoom = true;
                }
            }

            Assert.IsTrue(hasRoom);
        }

        [Test]
        public void Should_DeleteOneRoom_When_DeletingARoom()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(factory => factory.SendRequest(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Action<RequestResponse<string>>>(),
                    It.IsAny<bool>()))
                .Callback<string, string, string, Dictionary<string, string>, string, string,
                    Action<RequestResponse<string>>, bool>(
                    (_, _, _, _, _, _, cb, _) =>
                    {
                        var response = new RequestResponse<string>
                        {
                            Result = createRoomResponse,
                            Status = RequestStatus.Success,
                        };

                        cb.Invoke(response);
                    });

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            RoomData roomCreated = default;

            roomsService.CreateRoom(room =>
            {
                roomCreated = room.Result;
            }, RoomCreationOptions.Default);

            SetupRequestCallback(requestMock, (_, _, _, _, _, _, _, cb, _) =>
            {
                var response = new RequestResponse<string>
                {
                    Result = string.Empty,
                    Status = RequestStatus.Success,
                };

                cb.Invoke(response);
            });

#pragma warning disable CS0618
            roomsService.RemoveRoom(roomCreated.UniqueId, roomCreated.Secret, null);
#pragma warning restore CS0618

            var hasRoom = false;

            foreach (var room in roomsService.CachedRooms)
            {
                if (room.UniqueId == roomCreated.UniqueId)
                {
                    hasRoom = true;
                }
            }

            Assert.IsFalse(hasRoom);
        }

        [Test]
        public async Task Should_DeleteOneRoom_When_DeletingARoomAsync()
        {
            var requestFactory = new MockRequestFactoryBuilder()
                .SendRequestAsyncReturns(
                    () => Task.FromResult(createRoomResponse),
                    () => Task.FromResult(string.Empty))
                .Build();

            var credentials = new CloudCredentialsPair(authClient.Object, requestFactory);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var roomCreated = await roomsService.CreateRoomAsync(RoomCreationOptions.Default);

#pragma warning disable CS0618
            await roomsService.RemoveRoomAsync(roomCreated.UniqueId, roomCreated.Secret);
#pragma warning restore CS0618

            var hasRoom = false;

            foreach (var room in roomsService.CachedRooms)
            {
                if (room.UniqueId == roomCreated.UniqueId)
                {
                    hasRoom = true;
                }
            }

            Assert.IsFalse(hasRoom);
        }

        [Test]
        [Description("Verifies that a room is removed from the cache when deleted using the RoomData overload.")]
        public void Should_DeleteOneRoom_When_DeletingARoomWithRoomData()
        {
            var requestFactory = new MockRequestFactoryBuilder()
                .SendRequestReturns(createRoomResponse, string.Empty)
                .Build();

            var credentials = new CloudCredentialsPair(authClient.Object, requestFactory);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            RoomData roomCreated = default;

            roomsService.CreateRoom(room =>
            {
                roomCreated = room.Result;
            }, RoomCreationOptions.Default);

            roomsService.RemoveRoom(roomCreated, null);

            var hasRoom = false;

            foreach (var room in roomsService.CachedRooms)
            {
                if (room.UniqueId == roomCreated.UniqueId)
                {
                    hasRoom = true;
                }
            }

            Assert.IsFalse(hasRoom);
        }

        [Test]
        [Description("Verifies that a room is removed from the cache when deleted using the RoomData async overload.")]
        public async Task Should_DeleteOneRoom_When_DeletingARoomWithRoomDataAsync()
        {
            var requestFactory = new MockRequestFactoryBuilder()
                .SendRequestAsyncReturns(
                    () => Task.FromResult(createRoomResponse),
                    () => Task.FromResult(string.Empty))
                .Build();

            var credentials = new CloudCredentialsPair(authClient.Object, requestFactory);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var roomCreated = await roomsService.CreateRoomAsync(RoomCreationOptions.Default);

            await roomsService.RemoveRoomAsync(roomCreated);

            var hasRoom = false;

            foreach (var room in roomsService.CachedRooms)
            {
                if (room.UniqueId == roomCreated.UniqueId)
                {
                    hasRoom = true;
                }
            }

            Assert.IsFalse(hasRoom);
        }

        [Test]
        public async Task Should_ThrowOperationCanceledException_When_FetchRoomsAsyncReceivesAlreadyCancelledToken()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var cts = new CancellationTokenSource();
            cts.Cancel();

            await AssertThrowsAsync<OperationCanceledException>(() => roomsService.FetchRoomsAsync(null, cts.Token));
        }

        [Test]
        public async Task Should_ThrowOperationCanceledException_When_CreateRoomAsyncReceivesAlreadyCancelledToken()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var cts = new CancellationTokenSource();
            cts.Cancel();

            await AssertThrowsAsync<OperationCanceledException>(() => roomsService.CreateRoomAsync(RoomCreationOptions.Default, cts.Token));
        }

        [Test]
        public async Task Should_ThrowOperationCanceledException_When_RemoveRoomAsyncReceivesAlreadyCancelledToken()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var cts = new CancellationTokenSource();
            cts.Cancel();

            var roomData = new RoomData { UniqueId = 123, Secret = "secret" };

            await AssertThrowsAsync<OperationCanceledException>(() => roomsService.RemoveRoomAsync(roomData, cts.Token));
        }

        [Test]
        public async Task Should_ThrowOperationCanceledException_When_UnlistRoomAsyncReceivesAlreadyCancelledToken()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var cts = new CancellationTokenSource();
            cts.Cancel();

            var roomData = new RoomData { UniqueId = 123, Secret = "secret" };

            await AssertThrowsAsync<OperationCanceledException>(() => roomsService.UnlistRoomAsync(roomData, cts.Token));
        }

        [Test]
        public async Task Should_ThrowOperationCanceledException_When_MatchRoomAsyncReceivesAlreadyCancelledToken()
        {
            var requestMock = new Mock<IRequestFactoryInternal>(MockBehavior.Strict);
            requestMock.Setup(f => f.GetRequestCooldown(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(TimeSpan.Zero);

            var credentials = new CloudCredentialsPair(authClient.Object, requestMock.Object);
            using var roomsService = new CloudRoomsService("mock", credentials, runtimeSettings.Object);

            var cts = new CancellationTokenSource();
            cts.Cancel();

            await AssertThrowsAsync<OperationCanceledException>(() => roomsService.MatchRoomAsync(null, cts.Token));
        }

        private static async Task<TException> AssertThrowsAsync<TException>(Func<Task> action)
            where TException : Exception
        {
            try
            {
                await action();
            }
            catch (TException ex)
            {
                return ex;
            }
            catch (Exception ex)
            {
                Assert.Fail($"Expected exception of type {typeof(TException)} but got {ex.GetType()}: {ex}");
                throw;
            }

            Assert.Fail($"Expected exception of type {typeof(TException)} but no exception was thrown.");
            return null;
        }
    }
}
