// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Simulator
{
    using Cloud;
    using Common;
    using Toolkit;
    using Connection;
    using Log;
    using Logger = Log.Logger;
    using System.Collections;
    using System.Linq;
    using Cloud.Coroutines;
    using UnityEngine;

    [AddComponentMenu("coherence/Simulators/Auto Simulator Connection")]
    [HelpURL("https://docs.coherence.io/v/2.2/manual/simulation-server/client-vs-simulator-logic#connecting-simulators-automatically-to-rs-autosimulatorconnection-component")]
    [CoherenceDocumentation(DocumentationKeys.AutoSimulatorConnection)]
    public class AutoSimulatorConnection : MonoBehaviour
    {

#if UNITY_EDITOR
        /// <summary>
        /// Contains names of serialized properties.
        /// </summary>
        internal static class Property
        {
            public const string bridge = nameof(bridge);
        }
#endif
        [Min(0f)]
        public float reconnectTime = 3f;
        [Tooltip("Number of connection attempts before trying to resolve the endpoint again.\n\nOnly applies to Worlds.")]
        public int attemptsBeforeRefetch = 3;
        [Tooltip("Try to log in to Cloud as guest. If logged in already, this step will be skipped.\n\nOnly applies to Worlds.")]
        public bool autoLoginToCloud = true;

        [SerializeField, Tooltip("CoherenceBridge to use for reconnection. If empty, searches for a bridge in the current scene.")]
        private CoherenceBridge bridge;

        private PlayerAccount playerAccount;
        private bool shouldDisposePlayerAccount;

#if !UNITY_2022_2_OR_NEWER
        private readonly System.Threading.CancellationTokenSource destroyCancellationTokenSource = new();
        private System.Threading.CancellationToken destroyCancellationToken => destroyCancellationTokenSource.Token;
#endif

        /// <summary>
        /// CoherenceBridge to use for reconnection.
        /// </summary>
        /// <remarks>
        /// If empty at <see cref="Start"/>, it uses the CoherenceBridge registered for the current scene.
        /// If you want to change the associated CoherenceBridge at runtime, use <see cref="TrySetBridge"/>.
        /// </remarks>
        /// <seealso cref="TrySetBridge"/>
        public CoherenceBridge Bridge => bridge;

        /// <summary>
        /// Attempts to set a custom CoherenceBridge to be used for connection.
        /// </summary>
        /// <remarks>
        /// A CoherenceBridge can be safely switched when this component hasn't established a connection yet. If you
        /// want to update this reference at a point where this component has already established a connection, disconnect
        /// the associated CoherenceBridge via <see cref="CoherenceBridge.Disconnect"/> first.
        /// </remarks>
        /// <param name="bridge">The CoherenceBridge to use.</param>
        /// <returns><see langword="true"/> if this component isn't connected (hence a different bridge can be safely used); <see langword="false"/> otherwise.</returns>
        public bool TrySetBridge(CoherenceBridge bridge)
        {
            if (this.bridge && (this.bridge.IsConnecting || this.bridge.IsConnected))
            {
                return false;
            }

            Initialize(bridge);

            return true;
        }

        private void Initialize(CoherenceBridge bridge)
        {
            this.bridge = bridge;
            if (client != null)
            {
                client.OnConnected -= NetworkOnConnected;
                client.OnDisconnected -= NetworkOnDisconnected;
                client.OnConnectedEndpoint -= OnConnectedEndpoint;
                client = null;
            }

            if (bridge && bridge.Client != null)
            {
                client = bridge.Client;
                client.OnConnected += NetworkOnConnected;
                client.OnDisconnected += NetworkOnDisconnected;
                client.OnConnectedEndpoint += OnConnectedEndpoint;
            }
        }

        public EndpointData Endpoint => endpoint;

        private Logger logger;
        private EndpointData endpoint;
        private Coroutine reconnectCoroutine;
        private IClient client;
        private EndpointData lastConnectedEndpoint;
        private int currentReconnectAttempts;
        private bool quitting;

        private EndpointData CommandLineRoomEndpoint => new()
        {
            roomId = (ushort)SimulatorUtility.RoomId,
            uniqueRoomId = SimulatorUtility.UniqueRoomId,
            host = SimulatorUtility.Ip,
            port = SimulatorUtility.Port,
            runtimeKey = RuntimeSettings.Instance.RuntimeKey,
            schemaId = RuntimeSettings.Instance.SchemaID,
            worldId = SimulatorUtility.WorldId,
            authToken = SimulatorUtility.AuthToken,
            region = SimulatorUtility.Region,
        };
        private bool IsSimulator => SimulatorUtility.IsSimulator || client?.ConnectionType == ConnectionType.Simulator;
        private bool UsingWorld => SimulatorUtility.SimulatorType == SimulatorUtility.Type.World;

        private void Awake()
        {
            logger = Log.GetLogger<AutoSimulatorConnection>(this);

            Initialize(bridge);
        }

        private IEnumerator Start()
        {
            logger.Context = gameObject;
            if (!bridge)
            {
                if (CoherenceBridgeStore.TryGetBridge(gameObject.scene, out var sceneBridge))
                {
                    if (!TrySetBridge(sceneBridge))
                    {
                        logger.Info("Trying to set a CoherenceBridge, but the currently assigned CoherenceBridge is connecting or connected.");
                    }
                }
                else
                {
                    logger.Error(Error.SimulatorAutoConnectBridge, $"{nameof(CoherenceBridge)} not found.");
                    yield break;
                }
            }

            if (SimulatorUtility.IsInvokedAsSimulator)
            {
                var args = string.Join(' ', System.Environment.GetCommandLineArgs());
                logger.Info($"Invoked as hosted simulator. Arguments: {args}");

                endpoint = CommandLineRoomEndpoint;
                logger.Info($"Taking endpoint from command-line args: {endpoint}");

                logger.Info("Detected simulator type: " + SimulatorUtility.SimulatorType);
                if (UsingWorld)
                {
                    yield return StartCoroutine(ResolveWorldEndpoint());
                }
            }
            else
            {
                logger.Info($"Not invoked as hosted simulator, waiting for {nameof(CoherenceBridge)} to connect.");

                while (!bridge.IsConnected)
                {
                    yield return null;
                }

                endpoint = lastConnectedEndpoint;
                if (bridge.Client.ConnectionType != ConnectionType.Simulator)
                {
                    logger.Info($"Disabling: scene not connected as simulator.");
                    enabled = false;
                    yield break;
                }
            }

            var isValid = endpoint.ValidateLocalAddress().HasFlag(EndpointData.ValidationResult.ValidEndpoint);
            if (!isValid)
            {
                logger.Error(Error.SimulatorAutoConnectEndpoint, $"Disabling: Failed to resolve endpoint: {endpoint}.");
                enabled = false;
                yield break;
            }

            StartReconnect();
        }

        private void OnConnectedEndpoint(EndpointData endpointData)
        {
            lastConnectedEndpoint = endpointData;
        }

        private void OnApplicationQuit()
        {
            quitting = true;
        }

        private void OnDestroy()
        {
#if !UNITY_2022_2_OR_NEWER
            destroyCancellationTokenSource.Cancel();
#endif

            if (client != null)
            {
                client.OnConnected -= NetworkOnConnected;
                client.OnDisconnected -= NetworkOnDisconnected;
                client.OnConnectedEndpoint -= OnConnectedEndpoint;
            }

            if (shouldDisposePlayerAccount)
            {
                shouldDisposePlayerAccount = false;
                playerAccount?.Dispose();
            }
        }

        private void NetworkOnConnected(ClientID _)
        {
            if (IsSimulator)
            {
                logger.Info("Connection successful.");
                currentReconnectAttempts = 0;
            }
        }

        private void NetworkOnDisconnected(ConnectionCloseReason connectionCloseReason)
        {
            if (!quitting && client.ConnectionType == ConnectionType.Simulator)
            {
                logger.Error(Error.SimulatorAutoConnectDisconnected, ("reason", connectionCloseReason));
                StartReconnect();
            }
        }

        private void StartReconnect()
        {
            if (reconnectCoroutine != null)
            {
                StopCoroutine(reconnectCoroutine);
            }

            reconnectCoroutine = StartCoroutine(Reconnect());
        }

        private IEnumerator Reconnect()
        {
            logger.Info("Client not found. Waiting for a CoherenceBridge...");
            while (client == null)
            {
                yield return null;
            }

            var connected = client.IsConnected();
            if (connected)
            {
                logger.Info("Connected.");
                yield break;
            }

            while (true)
            {
                if (client.IsDisconnected())
                {
                    logger.Info("Attempting reconnect to: " + endpoint);

                    Connect();
                    currentReconnectAttempts++;
                }

                connected = client.IsConnected();
                if (connected)
                {
                    logger.Info("Connected.");
                    currentReconnectAttempts = 0;
                    yield break;
                }

                if (UsingWorld && attemptsBeforeRefetch > 0 && currentReconnectAttempts > attemptsBeforeRefetch)
                {
                    logger.Info($"Attempting to resolve world endpoint + reconnect in {reconnectTime} seconds.");
                    yield return new WaitForSeconds(reconnectTime);
                    yield return ResolveWorldEndpoint();
                    StartReconnect();
                    yield break;
                }

                logger.Info("Attempting to connect. Attempt " + currentReconnectAttempts);
                yield return new WaitForSeconds(reconnectTime);
                connected = client.IsConnected();
                if (connected)
                {
                    logger.Info("Connected.");
                    currentReconnectAttempts = 0;
                    yield break;
                }
            }
        }

        private void Connect()
        {
            logger.Info($"Connecting as simulator to endpoint {endpoint}",
                ("slug", RuntimeSettings.Instance.SimulatorSlug),
                ("sdkVersion", RuntimeSettings.Instance.SdkVersion),
                ("rsVersion", RuntimeSettings.Instance.RsVersion));

            var settings = ConnectionSettings.Default;
            settings.UseDebugStreams = RuntimeSettings.Instance.UseDebugStreams;

            // if version is uninitialized, use the one in runtime settings
            if (string.IsNullOrEmpty(endpoint.rsVersion))
            {
                endpoint.rsVersion = RuntimeSettings.Instance.RsVersion;
            }

            client.Connect(endpoint, settings, ConnectionType.Simulator);
        }

        private IEnumerator ResolveWorldEndpoint()
        {
            logger.Info($"Resolving world endpoint: {endpoint}");
            EndpointData newEndpoint;
            if (SimulatorUtility.Region == SimulatorUtility.LocalRegionParameter)
            {
                newEndpoint = new EndpointData
                {
                    host = SimulatorUtility.Ip,
                    port = SimulatorUtility.Port != 0 ? SimulatorUtility.Port : (RuntimeSettings.Instance.IsWebGL ? RuntimeSettings.Instance.LocalWorldWebPort : RuntimeSettings.Instance.LocalWorldUDPPort),
                    worldId = SimulatorUtility.WorldId,
                    runtimeKey = RuntimeSettings.Instance.RuntimeKey,
                    schemaId = RuntimeSettings.Instance.SchemaID,
                    authToken = SimulatorUtility.AuthToken,
                    region = SimulatorUtility.Region,
                };
                endpoint = newEndpoint;
                logger.Info($"Resolved local world endpoint: {endpoint}");
            }
            else
            {
                playerAccount = PlayerAccount.Main;
                if (playerAccount is null && autoLoginToCloud)
                {
                    logger.Info($"Logging in to coherence Cloud as a {(SimulatorUtility.IsSimulator ? "simulator" : "guest")}...");

                    CoherenceCloud.OnLoggingIn += OnLoggingIn;
                    var loginOperation = SimulatorUtility.IsSimulator
                        ? CoherenceCloud.LoginAsSimulator(RuntimeSettings.Instance, destroyCancellationToken)
                        : CoherenceCloud.LoginAsGuest(destroyCancellationToken);
                    while (!loginOperation.IsCompleted)
                    {
                        yield return null;
                    }

                    if (loginOperation.HasFailed)
                    {
                        logger.Error(Error.SimulatorAutoConnectCloudFailed, $"Cloud login failed: {loginOperation.Error.Message}");
                        yield break;
                    }

                    logger.Info($"Logged in as {(SimulatorUtility.IsSimulator ? "simulator" : "guest")}: {loginOperation.Result}. ");

                    void OnLoggingIn(PlayerAccount accountLoggingIn)
                    {
                        playerAccount = accountLoggingIn;
                        shouldDisposePlayerAccount = true;
                        CoherenceCloud.OnLoggingIn -= OnLoggingIn;
                    }
                }
                else if (playerAccount is null)
                {
                    logger.Info("Waiting until logged in to coherence Cloud...");
                    var getMainPlayerAccount = PlayerAccount.GetMainAsync(destroyCancellationToken);
                    yield return getMainPlayerAccount;
                    playerAccount = getMainPlayerAccount.Result;
                }
                else if (!playerAccount.IsLoggedIn)
                {
                    logger.Info("Waiting until logged in to coherence Cloud...");
                    do
                    {
                        yield return null;
                    }
                    while (!playerAccount.IsLoggedIn);
                }

                var worldsService = playerAccount.Services.Worlds;

                while(true)
                {
                    logger.Info("Fetching worlds...");
                    var fetchWorldsReq = worldsService.WaitForFetchWorlds(endpoint.region, RuntimeSettings.Instance.SimulatorSlug);
                    yield return fetchWorldsReq;

                    var response = fetchWorldsReq.RequestResponse;
                    if (response.Status == RequestStatus.Fail)
                    {
                        logger.Error(Error.SimulatorAutoConnectWorldIDFailed, $"World fetching failed: {response.Exception.Message}\n.Retrying in {reconnectTime} seconds...\nworldId: {endpoint.worldId}, region: \"{endpoint.region}\", simulatorSlug: \"{RuntimeSettings.Instance.SimulatorSlug}\"");
                        yield return new WaitForSeconds(reconnectTime);
                        continue;
                    }

                    var worlds = response.Result;

                    // If the world is still starting, an empty list is returned.
                    // In that case, keep retrying to give the world time to start.
                    if (worlds.Count is 0)
                    {
                        logger.Info($"Worlds fetching returned no results. World may still be starting. Retrying in {reconnectTime} seconds...\nworldId: {endpoint.worldId}, region: \"{endpoint.region}\", simulatorSlug: \"{RuntimeSettings.Instance.SimulatorSlug}\"");
                        yield return new WaitForSeconds(reconnectTime);
                        continue;
                    }

                    logger.Info($"Worlds fetching OK: {string.Join(',', worlds.Select(w => w.WorldId))}");

                    foreach (var worldData in worlds)
                    {
                        if (worldData.WorldId == endpoint.worldId)
                        {
                            newEndpoint = new EndpointData
                            {
                                host = worldData.Host.Ip,
                                port = worldData.Host.UDPPort,
                                worldId = worldData.WorldId,
                                runtimeKey = RuntimeSettings.Instance.RuntimeKey,
                                schemaId = RuntimeSettings.Instance.SchemaID,
                                authToken = SimulatorUtility.AuthToken,
                                region = SimulatorUtility.Region,
                            };
                            endpoint = newEndpoint;
                            logger.Info($"Found world that matches id '{endpoint.worldId}'. New endpoint = {endpoint}.");
                        }
                    }

                    yield break;
                }
            }
        }
    }
}
