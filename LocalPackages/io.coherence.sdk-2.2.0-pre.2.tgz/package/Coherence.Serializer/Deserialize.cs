// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Serializer
{
    using Brook;
    using SimulationFrame;
    using Entities;
    using Log;
    using System.Collections.Generic;
    using ProtocolDef;
    using System;
    using System.IO;
    using System.Numerics;
    using Coherence.Common;

    public static class Deserialize
    {
        // use native array instead of list in the future for performance
        public static void ReadWorldUpdate(
            List<IncomingEntityUpdate> updatesBuffer,
            AbsoluteSimulationFrame referenceSimulationFrame,
            Vector3d floatingOrigin,
            ProtocolDefinition schemaDefinition,
            ISchemaDataFactory schemaDataFactory,
            IInBitStream bitStream,
            ChannelID channelID,
            Logger logger)
        {
            Entities.Index lastIndex = 0;
            try
            {
                while (ReadEntity(bitStream, referenceSimulationFrame, ref lastIndex, out EntityWithMeta meta, out AbsoluteSimulationFrame entityRefSimulationFrame, logger))
                {
                    var entityUpdate = IncomingEntityUpdate.New(schemaDataFactory);
                    entityUpdate.TakeOwnershipOfComponents("Deserialize.ReadWorldUpdate");
                    if (meta.HasMeta)
                    {
                        entityUpdate.Meta = meta;
                    }

                    if (meta.IsAlive)
                    {
                        entityUpdate = UpdateComponents(schemaDefinition, schemaDataFactory, entityUpdate.ReleaseOwnershipOfComponents(), entityRefSimulationFrame, bitStream, logger);
                        entityUpdate.TakeOwnershipOfComponents("Deserialize.ReadWorldUpdate");
                    }

                    entityUpdate.Components.Updates.FloatingOrigin = floatingOrigin;
                    entityUpdate.ChannelID = channelID;

                    logger.Trace("read entity",
                        ("entity", entityUpdate.Entity),
                        ("isAlive", meta.IsAlive),
                        ("comps", entityUpdate));

                    updatesBuffer.Add(entityUpdate.ReleaseOwnershipOfComponents());
                }
            }
            catch
            {
                foreach (var update in updatesBuffer)
                {
                    update.Dispose();
                }

                throw;
            }
        }

        public static IncomingEntityUpdate UpdateComponents(
            ProtocolDefinition schemaDefinition,
            ISchemaDataFactory schemaDataFactory,
            IncomingEntityUpdate entityUpdate,
            AbsoluteSimulationFrame entityRefSimulationFrame,
            IInBitStream bitStream,
            Logger logger)
        {
            entityUpdate.TakeOwnershipOfComponents("Deserialize.UpdateComponents");

            var componentCount = ReadComponentCount(bitStream);
            try
            {
                for (var i = 0; i < componentCount; i++)
                {
                    var state = ReadComponentState(bitStream);
                    var componentId = ReadComponentId(bitStream);

                    switch (state)
                    {
                        case ComponentState.Update:
                            {
                                var componentData = ReadComponentData(schemaDefinition, schemaDataFactory, bitStream, componentId, entityRefSimulationFrame, logger);
                                componentData.TakeOwnership("Deserialize.UpdateComponents");

                                entityUpdate.Components.UpdateComponent(componentData.ReleaseOwnership());
                            }
                            break;
                        case ComponentState.Destruct:
                            {
                                var destroyComponentTypeId = componentId;
                                entityUpdate.Components.RemoveComponent(destroyComponentTypeId);
                            }
                            break;
                        default:
                            throw new ArgumentOutOfRangeException(nameof(state), $"expected ComponentState {ComponentState.Update} or {ComponentState.Destruct}, received: {state}. The replication server might be outdated.");
                    }
                }

                return entityUpdate.ReleaseOwnershipOfComponents();
            }
            catch
            {
                entityUpdate.Dispose();
                throw;
            }
        }

        public static bool ReadEntity(IInBitStream bitStream,
            AbsoluteSimulationFrame referenceSimulationFrame,
            ref Entities.Index lastIndex,
            out EntityWithMeta meta,
            out AbsoluteSimulationFrame entityRefSimulationFrame,
            Logger logger)
        {
            entityRefSimulationFrame = referenceSimulationFrame;

            var entityIndex = (Entities.Index)ReadEntityIndex(bitStream, lastIndex);
            if (entityIndex == Entity.EndOfEntities)
            {
                meta = new EntityWithMeta
                {
                    EntityId = Entity.InvalidRelative,
                    HasMeta = false,
                };
                return false;
            }

            meta = ReadEntityPotentialMeta(entityIndex, bitStream, logger);

            if (!meta.IsDestroyed)
            {
                entityRefSimulationFrame = ReadSimulationFrame(bitStream, referenceSimulationFrame);
            }

            lastIndex = entityIndex;

            return true;
        }

        private static ComponentData ReadComponentData(
            ProtocolDefinition schemaDefinition,
            ISchemaDataFactory schemaDataFactory,
            IInBitStream bitStream,
            uint componentID,
            AbsoluteSimulationFrame entityRefSimulationFrame,
            Logger logger)
        {
            var inProtocolStream = new InProtocolBitStream(bitStream);

            var component = schemaDataFactory.CreateComponent(componentID);
            component.TakeOwnership("Deserialize.ReadComponentData");

            try
            {
                if (inProtocolStream.ReadMask())
                {
                    component.StoppedMask = inProtocolStream.ReadMaskBits((uint)component.FieldCount);
                }

                foreach (var field in component.Fields)
                {
                    if (inProtocolStream.ReadMask())
                    {
                        DeserializeComponentFieldData(inProtocolStream, field, entityRefSimulationFrame);
                        component.FieldsMask |= field.Mask;
                    }
                }

                if (component.HasBaseComponent)
                {
                    var baseComponentDefinition = schemaDefinition.GetComponentDefinition(component.BaseComponentID);
                    component.SetComponentDefinition(baseComponentDefinition);
                }

                return component.ReleaseOwnership();
            }
            catch
            {
                component.Dispose();
                throw;
            }
        }

        private static void DeserializeComponentFieldData(
            InProtocolBitStream stream,
            FieldData field,
            AbsoluteSimulationFrame entityRefSimulationFrame)
        {
            if (field.HasSimFrames)
            {
                var simFrameDelta = DeserializerTools.ReadFieldSimFrameDelta(stream);
                var simFrame = entityRefSimulationFrame + simFrameDelta;
                field.SetSimFrame(simFrame);
            }

            FieldSerializer.DeserializeFieldData(stream, field);
        }

        private static AbsoluteSimulationFrame ReadSimulationFrame(IInBitStream bitStream, AbsoluteSimulationFrame referenceSimulationFrame)
        {
            bool hasFrameDelta = bitStream.ReadBits(Serialize.NUM_BITS_FOR_SIMFRAME_DELTA_FLAG) != 0;
            if (!hasFrameDelta)
            {
                return referenceSimulationFrame;
            }

            short frameDelta = DeserializerTools.ReadShortVarIntSigned(bitStream);

            var isSampleStale = frameDelta == -byte.MaxValue;

            if (isSampleStale)
            {
                return AbsoluteSimulationFrame.Invalid;
            }

            return new AbsoluteSimulationFrame { Frame = referenceSimulationFrame + frameDelta };
        }

        private static uint ReadEntityIndex(IInBitStream bitstream, Entities.Index lastIndex)
        {
            uint delta = DeserializerTools.ReadShortVarInt(bitstream);
            if ((Entities.Index)delta == Entity.EndOfEntities)
            {
                return delta;
            }

            uint sign = bitstream.ReadBits(1);
            uint index = (uint)((uint)lastIndex + (delta * (sign == 1 ? 1 : -1)));

            return index;
        }

        private static EntityWithMeta ReadEntityPotentialMeta(Entities.Index entityIndex, IInBitStream bitStream, Logger logger)
        {
            bool hasMeta = bitStream.ReadBits(1) != 0;
            if (hasMeta)
            {
                SerializedMeta meta = ReadEntityMeta(bitStream);

                // Potential entity construct
                Entity completeEntityId = new Entity(entityIndex, meta.Version, Entity.Relative);

                EntityWithMeta entityWithMeta = new EntityWithMeta
                {
                    EntityId = completeEntityId,
                    HasMeta = true,
                    HasStateAuthority = meta.HasStateAuthority,
                    HasInputAuthority = meta.HasInputAuthority,
                    IsOrphan = meta.IsOrphan,
                    LOD = meta.LOD,
                    Operation = meta.Operation,
                    DestroyReason = meta.DestroyReason,
                };

                return entityWithMeta;
            }

            logger.Trace("entity update");

            // Find a previous entity
            Entity entityId = default;
            EntityWithMeta entityWithoutMeta = new EntityWithMeta
            {
                EntityId = entityId,
                HasMeta = false,
                HasStateAuthority = false,
                IsOrphan = false,
                LOD = 0,
                Operation = EntityOperation.Update
            };

            return entityWithoutMeta;
        }

        private static SerializedMeta ReadEntityMeta(IInBitStream bitstream)
        {
            var version = ReadEntityVersion(bitstream);
            bool stateAuthority = ReadEntityAuthority(bitstream);
            bool inputAuthority = ReadEntityAuthority(bitstream);
            bool orphan = ReadEntityOrphan(bitstream);
            uint lod = ReadEntityLOD(bitstream);
            EntityOperation operation = ReadEntityOperation(bitstream);

            var destroyReason = DestroyReason.BadReason;
            if (operation == EntityOperation.Destroy)
            {
                destroyReason = ReadDestroyReason(bitstream);
            }

            return new SerializedMeta
            {
                Version = version,
                HasStateAuthority = stateAuthority,
                HasInputAuthority = inputAuthority,
                IsOrphan = orphan,
                LOD = lod,
                Operation = operation,
                DestroyReason = destroyReason,
            };
        }

        private static byte ReadEntityVersion(IInBitStream bitstream)
        {
            byte versionValue = (byte)bitstream.ReadBits(Entity.NumVersionBits);
            return versionValue;
        }

        private static bool ReadEntityAuthority(IInBitStream bitstream)
        {
            return bitstream.ReadBits(Serialize.NUM_BITS_FOR_AUTHORITY) != 0;
        }

        private static bool ReadEntityOrphan(IInBitStream bitstream)
        {
            return bitstream.ReadBits(Serialize.NUM_BITS_FOR_ORPHAN) != 0;
        }

        private static uint ReadEntityLOD(IInBitStream bitstream)
        {
            return (uint)bitstream.ReadBits(Serialize.NUM_BITS_FOR_LOD);
        }

        private static EntityOperation ReadEntityOperation(IInBitStream bitstream)
        {
            return (EntityOperation)bitstream.ReadBits(Serialize.NUM_BITS_FOR_OPERATION);
        }

        private static DestroyReason ReadDestroyReason(IInBitStream bitstream)
        {
            return (DestroyReason)bitstream.ReadBits(Serialize.NUM_BITS_FOR_DESTROY_REASON);
        }

        private static uint ReadComponentCount(IInBitStream bitstream)
        {
            return bitstream.ReadBits(Serialize.NUM_BITS_FOR_COMPONENT_COUNT);
        }

        private static ComponentState ReadComponentState(IInBitStream bitstream)
        {
            uint stateValue = bitstream.ReadBits(Serialize.NUM_BITS_FOR_COMPONENT_STATE);
            return (ComponentState)stateValue;
        }

        private static uint ReadComponentId(IInBitStream bitstream)
        {
            return ReadComponentTypeId(bitstream);
        }

        private static uint ReadComponentTypeId(IInBitStream bitstream)
        {
            return bitstream.ReadUint16();
        }

        public static Vector3d ReadFloatingOrigin(IInBitStream bitstream, Logger logger)
        {
            var protocolBitStream = new InProtocolBitStream(bitstream);

            var floatingOrigin = protocolBitStream.ReadVector3d();
            logger.Trace("FloatingOrigin", ("position", floatingOrigin));
            return floatingOrigin;
        }

        public static bool ReadChannelID(IInBitStream bitstream, out ChannelID channelID)
        {
            channelID = (ChannelID)bitstream.ReadBits(Serialize.NUM_BITS_FOR_CHANNEL_ID);
            return channelID != ChannelID.EndOfChannels;
        }
    }
}

