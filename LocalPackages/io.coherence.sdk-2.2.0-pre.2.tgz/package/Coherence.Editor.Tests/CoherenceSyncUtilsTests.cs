namespace Coherence.Editor.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using Coherence.Tests;
    using Coherence.Toolkit;
    using Coherence.Toolkit.Bindings;
    using Coherence.Toolkit.Bindings.TransformBindings;
    using NUnit.Framework;
    using UnityEditor;
    using UnityEngine;
    using Object = UnityEngine.Object;

    [TestFixture(typeof(Transform))]
    [TestFixture(typeof(BoxCollider))]
    [TestFixture(typeof(AudioSource))]
    [TestFixture(typeof(CoherenceNode))]
    [TestFixture(typeof(CoherenceSync))]
    [TestFixture(typeof(Animator))]
    public class CoherenceSyncUtilsTests<T> : CoherenceTest where T : Component
    {
        private static readonly MemberInfo[] members;
        private static readonly MemberInfo[] bindableMembers;
        private static readonly MemberInfo[] nonBindableMembers;

        private static readonly string[] bindableMemberNames;
        private static readonly string[] nonBindableMemberNames;

        private static int onBeforeBindingAddedInvokeCount;
        private static int onBeforeBindingRemovedInvokeCount;

        private GameObject gameObject;
        private CoherenceSync sync;
        private T component;
        private List<Descriptor> descriptors;
        private IEnumerable<Descriptor> requiredDescriptors;
        private IEnumerable<Descriptor> availableDescriptors;
        private IEnumerable<Descriptor> nonAvailableDescriptors;

        static CoherenceSyncUtilsTests()
        {
            members = typeof(T).GetPubliclyAccessibleInstanceMembers().ToArray();
            bindableMembers = members.Where(m => m.IsValidBinding()).ToArray();
            nonBindableMembers = members.Except(bindableMembers).ToArray();

            bindableMemberNames = bindableMembers.Select(m => m.Name).Distinct().ToArray();
            nonBindableMemberNames = nonBindableMembers.Select(m => m.Name).Distinct().ToArray();
        }

        private void UpdateDescriptorCollections()
        {
            descriptors = EditorCache.GetComponentDescriptors(component);
            requiredDescriptors = descriptors.Where(d => d.Required);
            availableDescriptors = descriptors.Where(d => bindableMemberNames.Contains(d.Name));
            nonAvailableDescriptors = descriptors.Except(availableDescriptors);
        }

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();

            onBeforeBindingAddedInvokeCount = 0;
            onBeforeBindingRemovedInvokeCount = 0;
            CoherenceSyncUtils.OnBeforeBindingAdded += OnBeforeBindingAdded;
            CoherenceSyncUtils.OnBeforeBindingRemoved += OnBeforeBindingRemoved;

            gameObject = new GameObject();
            sync = gameObject.AddComponent<CoherenceSync>();
            if (!gameObject.TryGetComponent(out component))
            {
                component = gameObject.AddComponent<T>();
            }

            UpdateDescriptorCollections();
        }

        [TearDown]
        public override void TearDown()
        {
            CoherenceSyncUtils.OnBeforeBindingAdded -= OnBeforeBindingAdded;
            CoherenceSyncUtils.OnBeforeBindingRemoved -= OnBeforeBindingRemoved;

            Object.DestroyImmediate(gameObject, true);

            base.TearDown();
        }

        private static void OnBeforeBindingAdded(CoherenceSync sync, Binding binding)
        {
            onBeforeBindingAddedInvokeCount++;
        }

        private void OnBeforeBindingRemoved(CoherenceSync arg1, Binding arg2)
        {
            onBeforeBindingRemovedInvokeCount++;
        }

        [Test, Description("UpdateBindings with forceUpdate set to true should add all missing required bindings to non-prefab CoherenceSync.")]
        public void UpdateBindings_CreatesRequiredBindings()
        {
            var requiredCount = requiredDescriptors.Count(d => d.OwnerType == typeof(T));
            if (requiredCount == 0)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't define any required bindings.");
            }

            sync.Bindings.Clear();
            CoherenceSyncUtils.UpdateBindings(sync, forceUpdate:true);
            Assert.AreEqual(requiredCount, sync.Bindings.Count(b => b.unityComponent == component),
                string.Join(",", sync.Bindings.Select(b => b.Name)));
            Assert.IsTrue(EditorUtility.IsDirty(sync));
        }

        [Test, Description("UpdateBindings should not remove any bindings from a CoherenceSync that is the child of another CoherenceSync in a prefab asset.")]
        public void UpdateBindings_DoesNotRemoveBindingsFromNestedCoherenceSyncObject()
        {
            const string prefabResourcePath = "CoherenceSync/Parent";
            var prefab = Resources.Load<CoherenceSync>(prefabResourcePath);
            if (!prefab)
            {
                Assert.Ignore($"Test disabled because failed to find CoherenceSync test prefab at '{prefabResourcePath}'.");
            }
            var nestedSync = prefab.transform.GetChild(0).GetComponent<CoherenceSync>();
            var bindingsBeforeUpdate = nestedSync.Bindings.ToArray();

            var bindingsWereChanged = CoherenceSyncUtils.UpdateBindings(nestedSync, forceUpdate:false);

            Assert.That(bindingsWereChanged, Is.False);
            var bindingsAfterUpdate = nestedSync.Bindings;
            Assert.That(bindingsAfterUpdate, Is.EquivalentTo(bindingsBeforeUpdate));
            Assert.That(bindingsAfterUpdate.FirstOrDefault(), Is.TypeOf<PositionBinding>());
        }

        [Test, Description("Invalid bindings whose Descriptor is Required should be removed automatically as part of the UpdateBindings process.")]
        public void UpdateBindings_RemovesInvalidBindings_With_RequiredDescriptors()
        {
            if (component is Transform)
            {
                Assert.Ignore("Transform cannot be removed.");
            }

            var requiredCount = requiredDescriptors.Count(d => d.OwnerType == typeof(T));
            if (requiredCount == 0)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't define any required bindings.");
            }

            sync.Bindings.Clear();
            CoherenceSyncUtils.UpdateBindings(sync, forceUpdate:true);

            // We don't assert that the required bindings were added since that is covered by UpdateBindings_CreatesRequiredBindings
            Object.DestroyImmediate(component);
            var bindingsWereChanged = CoherenceSyncUtils.UpdateBindings(sync, forceUpdate:true);
            Assert.IsTrue(bindingsWereChanged);
            var count = sync.Bindings.Count(b => b.unityComponent == component);
            Assert.AreEqual(0, count, "Required bindings were not removed.");
            Assert.IsTrue(EditorUtility.IsDirty(sync));
        }

        [Test, Description("IsEditingBindingsAllowed(sync, InteractionMode.UserAction) should return True when CloneMode.Enabled is False, even if CloneMode.AllowEdits is false.")]
        public void IsEditingBindingsAllowed_With_InteractionMode_UserAction_Returns_True_When_CloneMode_Is_Disabled()
        {
            const string prefabResourcePath = "CoherenceSync/Parent";
            var sync = Resources.Load<CoherenceSync>(prefabResourcePath);
            if (!sync)
            {
                Assert.Ignore($"Test disabled because failed to find CoherenceSync test prefab at '{prefabResourcePath}'.");
            }

            var wasEnabled = CloneMode.Enabled;
            var editsWereAllowed = CloneMode.AllowEdits;
            bool isEditingBindingsAllowed;
            CloneMode.Enabled = false;
            CloneMode.AllowEdits = false;

            try
            {
                isEditingBindingsAllowed = CoherenceSyncUtils.IsEditingBindingsAllowed(sync, InteractionMode.UserAction);
            }
            finally
            {
                CloneMode.Enabled = wasEnabled;
                CloneMode.AllowEdits = editsWereAllowed;
            }

            Assert.That(isEditingBindingsAllowed, Is.True);
        }

        [Test, Description("IsEditingBindingsAllowed(sync, InteractionMode.AutomatedAction) should return True when CloneMode.Enabled is False, even if CloneMode.AllowEdits is False.")]
        public void IsEditingBindingsAllowed_With_InteractionMode_AutomatedAction_Returns_False_When_CloneMode_Is_Disabled()
        {
            const string prefabResourcePath = "CoherenceSync/Parent";
            var sync = Resources.Load<CoherenceSync>(prefabResourcePath);
            if (!sync)
            {
                Assert.Ignore($"Test disabled because failed to find CoherenceSync test prefab at '{prefabResourcePath}'.");
            }

            var wasEnabled = CloneMode.Enabled;
            var editsWereAllowed = CloneMode.AllowEdits;
            bool isEditingBindingsAllowed;
            CloneMode.Enabled = false;
            CloneMode.AllowEdits = false;

            try
            {
                isEditingBindingsAllowed = CoherenceSyncUtils.IsEditingBindingsAllowed(sync, InteractionMode.AutomatedAction);
            }
            finally
            {
                CloneMode.Enabled = wasEnabled;
                CloneMode.AllowEdits = editsWereAllowed;
            }

            Assert.That(isEditingBindingsAllowed, Is.True);
        }

        [Test, Description("IsEditingBindingsAllowed(sync, InteractionMode.UserAction) should return True when CloneMode.Enabled is True and CloneMode.AllowEdits is True.")]
        public void IsEditingBindingsAllowed_With_InteractionMode_UserAction_Returns_True_When_CloneMode_Is_Enabled_And_AllowEdits_Is_Enabled()
        {
            const string prefabResourcePath = "CoherenceSync/Parent";
            var sync = Resources.Load<CoherenceSync>(prefabResourcePath);
            if (!sync)
            {
                Assert.Ignore($"Test disabled because failed to find CoherenceSync test prefab at '{prefabResourcePath}'.");
            }

            var wasEnabled = CloneMode.Enabled;
            var editsWereAllowed = CloneMode.AllowEdits;
            bool isEditingBindingsAllowed;
            CloneMode.Enabled = true;
            CloneMode.AllowEdits = true;

            try
            {
                isEditingBindingsAllowed = CoherenceSyncUtils.IsEditingBindingsAllowed(sync, InteractionMode.UserAction);
            }
            finally
            {
                CloneMode.Enabled = wasEnabled;
                CloneMode.AllowEdits = editsWereAllowed;
            }

            Assert.That(isEditingBindingsAllowed, Is.True);
        }

        [Test, Description("IsEditingBindingsAllowed(sync, InteractionMode.UserAction) should return False when CloneMode.Enabled is True and CloneMode.AllowEdits is False.")]
        public void IsEditingBindingsAllowed_With_InteractionMode_UserAction_Returns_False_When_CloneMode_Is_Enabled_And_AllowEdits_Is_Disabled()
        {
            const string prefabResourcePath = "CoherenceSync/Parent";
            var sync = Resources.Load<CoherenceSync>(prefabResourcePath);
            if (!sync)
            {
                Assert.Ignore($"Test disabled because failed to find CoherenceSync test prefab at '{prefabResourcePath}'.");
            }

            var wasEnabled = CloneMode.Enabled;
            var editsWereAllowed = CloneMode.AllowEdits;
            bool isEditingBindingsAllowed;
            CloneMode.Enabled = true;
            CloneMode.AllowEdits = false;

            try
            {
                isEditingBindingsAllowed = CoherenceSyncUtils.IsEditingBindingsAllowed(sync, InteractionMode.UserAction);
            }
            finally
            {
                CloneMode.Enabled = wasEnabled;
                CloneMode.AllowEdits = editsWereAllowed;
            }

            Assert.That(isEditingBindingsAllowed, Is.False);
        }

        [Test, Description("IsEditingBindingsAllowed(sync, InteractionMode.AutomatedAction) should return False when CloneMode.Enabled is false, even if CloneMode.AllowEdits is True.")]
        public void IsEditingBindingsAllowed_With_InteractionMode_AutomatedAction_Returns_False_When_CloneMode_Is_Enabled()
        {
            const string prefabResourcePath = "CoherenceSync/Parent";
            var sync = Resources.Load<CoherenceSync>(prefabResourcePath);
            if (!sync)
            {
                Assert.Ignore($"Test disabled because failed to find CoherenceSync test prefab at '{prefabResourcePath}'.");
            }

            var wasEnabled = CloneMode.Enabled;
            var editsWereAllowed = CloneMode.AllowEdits;
            bool isEditingBindingsAllowed;
            CloneMode.Enabled = true;
            CloneMode.AllowEdits = true;

            try
            {
                isEditingBindingsAllowed = CoherenceSyncUtils.IsEditingBindingsAllowed(sync, InteractionMode.AutomatedAction);
            }
            finally
            {
                CloneMode.Enabled = wasEnabled;
                CloneMode.AllowEdits = editsWereAllowed;
            }

            Assert.That(isEditingBindingsAllowed, Is.False);
        }

        [Test, Description(
        "AddBinding<T> throws NonBindableException if member type is non-bindable; otherwise, adds a valid binding and sets the CoherenceSync dirty.\n" +
        "RemoveBinding<T> throws DescriptorRequiredException for required bindings; otherwise, removes the binding.")]
        public void AddAndRemoveBindings_ThroughGenericType()
        {
            CoherenceSyncUtils.UpdateBindings(sync, forceUpdate:true);

            foreach (var descriptor in availableDescriptors)
            {
                var memberName = descriptor.Name;
                var count = sync.Bindings.Count;
                if (TypeUtils.IsNonBindableType(typeof(T)))
                {
                    Assert.Throws<NonBindableException>(
                        () => CoherenceSyncUtils.AddBinding<T>(gameObject, memberName));
                    Assert.AreEqual(sync.Bindings.Count, count);

                    Assert.Throws<NonBindableException>(
                        () => CoherenceSyncUtils.RemoveBinding<T>(gameObject, memberName));
                    Assert.AreEqual(sync.Bindings.Count, count);
                }
                else
                {
                    var binding = CoherenceSyncUtils.AddBinding<T>(gameObject, memberName);
                    Assert.IsNotNull(binding, memberName);
                    Assert.IsTrue(binding.IsValid);
                    var checkValid = binding.IsBindingValid();
                    Assert.IsTrue(checkValid.IsValid, checkValid.Reason);
                    Assert.IsTrue(sync.Bindings.Contains(binding));
                    Assert.IsTrue(EditorUtility.IsDirty(sync));

                    CoherenceSyncUtils.AddBinding<T>(gameObject, memberName);
                    Assert.LessOrEqual(sync.Bindings.Count, count + 1);

                    if (requiredDescriptors.Contains(descriptor))
                    {
                        Assert.Throws<DescriptorRequiredException>(
                            () => CoherenceSyncUtils.RemoveBinding<T>(gameObject, memberName));
                    }
                    else
                    {
                        CoherenceSyncUtils.RemoveBinding<T>(gameObject, memberName);
                        Assert.GreaterOrEqual(sync.Bindings.Count, count - 1);
                    }
                }
            }

        }

        [Test, Description("AddBinding<T> throws DescriptorNotFoundException if no member by the given name exists on the component of type T attached to the GameObject.")]
        public void AddBinding_OnNonExistingMember()
        {
            // Using a member name that doesn't exist
            Assert.Throws<DescriptorNotFoundException>(
                () => CoherenceSyncUtils.AddBinding<T>(gameObject, "0"));
        }

        [Test, Description("AddBinding<T> throws DescriptorNotFoundException if member type is non-bindable.")]
        public void AddBinding_OnExistingMemberButNotBindable_Throws()
        {
            // Members existing on the type, that coherence doesn't support

            if (!nonBindableMemberNames.Any())
            {
                Assert.Ignore("All members of the given type can be bound to.");
            }

            foreach (var memberName in nonBindableMemberNames)
            {
                Assert.Throws<DescriptorNotFoundException>(
                    () => CoherenceSyncUtils.AddBinding<T>(gameObject, memberName), memberName);
            }
        }

        [Test, Description("AddBinding<T> throws DescriptorNotFoundException if member type is bindable, but DescriptorProvider has a custom filter excluding the member from the descriptors lists.")]
        public void AddBinding_OnFilteredOutDescriptor_Throws()
        {
            // Members existing on the type, that are bindable, but that the DescriptorProvider decides to not expose

            if (!nonAvailableDescriptors.Any())
            {
                Assert.Ignore($"The DescriptorProvider associated with {typeof(T).Name} exposes all bindable members.");
            }

            foreach (var descriptor in nonAvailableDescriptors)
            {
                var memberName = descriptor.Name;
                Debug.Log(memberName);
                Assert.Throws<DescriptorNotFoundException>(
                    () => CoherenceSyncUtils.AddBinding<T>(gameObject, memberName), memberName);
            }
        }

        [Test, Description(
        "The OnBeforeBindingAdded event is raised once, if AddBinding<T> succeeds in adding a binding; otherwise, the event is not raised at all.\n" +
        "The onBeforeBindingRemovedInvokeCount event is raised once, if RemoveBinding<T> succeeds in removing a binding; otherwise, the event is not raised at all.")]
        public void AddBinding_RaisesEvents()
        {
            if (TypeUtils.IsNonBindableType(typeof(T)))
            {
                Assert.Ignore("Component doesn't allow bindings.");
            }

            var descriptorCount = availableDescriptors.Count();
            if (descriptorCount == 0)
            {
                Assert.Ignore("Component doesn't expose any valid descriptor.");
            }

            var descriptor = descriptors.FirstOrDefault(descriptor => !descriptor.Required);
            if (descriptor == default)
            {
                Assert.Ignore("Component doesn't expose non-required descriptors.");
            }

            var memberName = descriptor.Name;

            CoherenceSyncUtils.AddBinding<T>(gameObject, memberName);
            Assert.AreEqual(1, onBeforeBindingAddedInvokeCount);

            CoherenceSyncUtils.AddBinding<T>(gameObject, memberName);
            Assert.AreEqual(onBeforeBindingAddedInvokeCount, 1, "Adding an existing binding triggered OnBeforeBindingAdded.");

            CoherenceSyncUtils.RemoveBinding<T>(gameObject, memberName);
            Assert.AreEqual(1, onBeforeBindingRemovedInvokeCount);

            CoherenceSyncUtils.RemoveBinding<T>(gameObject, memberName);
            Assert.AreEqual(1, onBeforeBindingRemovedInvokeCount, "Removing a non-existing binding triggered OnBeforeBindingRemoved.");
        }

        [Test, Description("Removing a binding whose component is missing should not fail.")]
        public void RemoveInvalidBinding_DoesNotThrow()
        {
            if (component is Transform)
            {
                Assert.Ignore("Transform cannot be removed.");
            }

            if (TypeUtils.IsNonBindableType(typeof(T)))
            {
                Assert.Ignore($"{typeof(T).Name} doesn't allow bindings.");
            }

            var descriptorCount = availableDescriptors.Count();
            if (descriptorCount == 0)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't expose any valid descriptor.");
            }

            var descriptor = descriptors.FirstOrDefault(descriptor => !descriptor.Required);
            if (descriptor == default)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't expose non-required descriptors.");
            }

            var memberName = descriptor.Name;
            CoherenceSyncUtils.AddBinding<T>(gameObject, memberName);

            Object.DestroyImmediate(component);

            CoherenceSyncUtils.RemoveBinding(gameObject, typeof(T), memberName);
        }

        [Test, Description("RemoveBindings should remove all specified bindings from the CoherenceSync and return the count of removed bindings.")]
        public void RemoveBindings_Removes_Given_Bindings()
        {
            if (TypeUtils.IsNonBindableType(typeof(T)))
            {
                Assert.Ignore($"{typeof(T).Name} doesn't allow bindings.");
            }

            var descriptorCount = availableDescriptors.Count();
            if (descriptorCount < 2)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't expose enough descriptors for this test.");
            }

            CoherenceSyncUtils.UpdateBindings(sync, forceUpdate: true);
            var bindingsToRemove = new List<Binding>();
            var initialBindings = sync.Bindings.ToArray();
            foreach (var descriptor in availableDescriptors.Where(x => !x.Required))
            {
                bindingsToRemove.Add(CoherenceSyncUtils.AddBinding(sync, component, descriptor));
            }

            if (bindingsToRemove.Count is 0)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't have non-required bindings to remove.");
            }

            var removedCount = CoherenceSyncUtils.RemoveBindings(sync, bindingsToRemove.ToArray());

            Assert.That(removedCount, Is.EqualTo(bindingsToRemove.Count), $"RemoveBindings({typeof(T).Name}, Binding[{bindingsToRemove.Count}]) did not return {bindingsToRemove.Count}.");
            Assert.That(sync.Bindings, Is.EquivalentTo(initialBindings), "The correct number of bindings should remain in the collection.");
            Assert.That(EditorUtility.IsDirty(sync), Is.True, "CoherenceSync should be marked as dirty after removing bindings.");
            Assert.That(sync.Archetype.BoundComponents.SelectMany(x => x.Bindings), Is.EquivalentTo(initialBindings), "Archetype's BoundComponent bindings should be updated as well.");
            Assert.That(BakeUtil.CoherenceSyncSchemasDirty, Is.True, "BakeUtil.CoherenceSyncSchemasDirty should be set to true after removing bindings.");
        }

        [Test, Description("RemoveBindings should handle null or empty binding arrays gracefully.")]
        public void RemoveBindings_Throws_ArgumentNullException_If_Given_Null_Array()
            => Assert.Throws<ArgumentNullException>(() => CoherenceSyncUtils.RemoveBindings(sync, default(Binding[])));

        [Test, Description("RemoveBindings should handle null or empty binding arrays gracefully.")]
        public void RemoveBindings_Returns_Zero_If_Given_Empty_Array()
        {
            var initialBindingCount = sync.Bindings.Count;

            var removedCount = CoherenceSyncUtils.RemoveBindings(sync, Array.Empty<Binding>());

            Assert.That(removedCount, Is.Zero, "RemoveBindings should return 0 when given an empty array.");
            Assert.That(sync.Bindings.Count, Is.EqualTo(initialBindingCount), "Binding count should remain unchanged with empty array.");
        }

        [Test, Description("RemoveBindings should handle duplicate bindings in the array without error.")]
        public void RemoveBindings_Ignores_Duplicates_In_Given_Array()
        {
            if (TypeUtils.IsNonBindableType(typeof(T)))
            {
                Assert.Ignore($"{typeof(T).Name} doesn't allow bindings.");
            }

            var descriptorCount = availableDescriptors.Count();
            if (descriptorCount == 0)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't expose any valid descriptor.");
            }

            CoherenceSyncUtils.UpdateBindings(sync, forceUpdate: true);
            var initialBindingCount = sync.Bindings.Count;

            // Get a non-required binding to remove
            var bindingToRemove = sync.Bindings.FirstOrDefault(b => ReferenceEquals(b.unityComponent, component) && !b.Descriptor.Required);
            if (bindingToRemove == null)
            {
                Assert.Ignore($"{typeof(T).Name} doesn't have non-required bindings to remove.");
            }

            var sameBindingTwice = new[] { bindingToRemove, bindingToRemove };

            var removedCount = CoherenceSyncUtils.RemoveBindings(sync, sameBindingTwice);

            // Should only remove the binding once, even though it appears twice in the array
            Assert.That(removedCount, Is.EqualTo(1), "RemoveBindings should only count each unique binding removal once.");
            Assert.That(sync.Bindings.Count, Is.EqualTo(initialBindingCount - 1), "Only one binding should be removed despite duplicates in the array.");
            Assert.That(sync.Bindings.Contains(bindingToRemove), Is.False, "The binding should have been removed from the collection.");
        }


    }

    [TestFixture]
    public class UpdateBindings_RequiredAttributeRemovedTests : CoherenceTest
    {
        // A component with a public method but no [Command] attribute.
        // Represents the state AFTER the attribute has been removed.
        private class ComponentWithPublicMethod : MonoBehaviour
        {
            public void MyCommand() { }
        }

        private GameObject gameObject;
        private CoherenceSync sync;
        private ComponentWithPublicMethod component;

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();
            gameObject = new GameObject();
            sync = gameObject.AddComponent<CoherenceSync>();
            component = gameObject.AddComponent<ComponentWithPublicMethod>();
        }

        [TearDown]
        public override void TearDown()
        {
            new DescriptorProvider().ClearDescriptorCache();
            Object.DestroyImmediate(gameObject);
            base.TearDown();
        }

        [Test, Description("UpdateBindings should remove a binding whose member no longer carries the [Command] attribute, even if the member itself still exists on the component.")]
        public void UpdateBindings_RemovesBinding_WhenCommandAttributeIsRemoved()
        {
            // Simulate a stale serialized state: a CommandBinding was created when [Command]
            // was present on MyCommand. Build the descriptor manually from the method info
            // and mark it required, as the serializer would have preserved.
            var methodInfo = typeof(ComponentWithPublicMethod).GetMethod(nameof(ComponentWithPublicMethod.MyCommand));
            var staleDescriptor = new Descriptor(typeof(ComponentWithPublicMethod), methodInfo);
            staleDescriptor.Required = true;

            var staleBinding = staleDescriptor.InstantiateBinding(component);
            sync.Bindings.Add(staleBinding);

            // The live descriptor (from reflection) is non-required because [Command] is gone.
            // UpdateBindings must detect this mismatch and remove the stale binding.
            var changed = CoherenceSyncUtils.UpdateBindings(sync, forceUpdate: true);

            Assert.That(changed, Is.True, "UpdateBindings should report a change.");
            Assert.That(sync.Bindings.Contains(staleBinding), Is.False, "The stale required binding should have been removed.");
        }

        [Test, Description("RemoveUnrecoverableBindings should remove a binding whose member no longer carries the [Command] attribute. This covers prefab variant processing, where UpdateBindings only iterates added components.")]
        public void RemoveUnrecoverableBindings_RemovesBinding_WhenCommandAttributeIsRemoved()
        {
            var methodInfo = typeof(ComponentWithPublicMethod).GetMethod(nameof(ComponentWithPublicMethod.MyCommand));
            var staleDescriptor = new Descriptor(typeof(ComponentWithPublicMethod), methodInfo);
            staleDescriptor.Required = true;

            var staleBinding = staleDescriptor.InstantiateBinding(component);
            sync.Bindings.Add(staleBinding);

            var removed = CoherenceSyncUtils.RemoveUnrecoverableBindings(sync);

            Assert.That(removed, Is.EqualTo(1), "RemoveUnrecoverableBindings should have removed the stale binding.");
            Assert.That(sync.Bindings.Contains(staleBinding), Is.False, "The stale binding should no longer be in the Bindings list.");
        }

        [Test, Description("UpdateBindings should be idempotent: a second call with no changes should report no modifications and leave existing non-required bindings intact.")]
        public void UpdateBindings_IsIdempotent_WhenNoChangesExist()
        {
            // Manually add a non-required binding (simulates a user-added binding for a public method).
            var methodInfo = typeof(ComponentWithPublicMethod).GetMethod(nameof(ComponentWithPublicMethod.MyCommand));
            var descriptor = new Descriptor(typeof(ComponentWithPublicMethod), methodInfo);
            var binding = descriptor.InstantiateBinding(component);
            sync.Bindings.Add(binding);

            // First call may or may not change; second call must report no changes.
            CoherenceSyncUtils.UpdateBindings(sync, forceUpdate: true);
            var secondChanged = CoherenceSyncUtils.UpdateBindings(sync, forceUpdate: true);

            Assert.That(secondChanged, Is.False, "Second UpdateBindings call should report no changes.");
            Assert.That(sync.Bindings.Contains(binding), Is.True, "Non-required binding should not have been removed.");
        }
    }
}
