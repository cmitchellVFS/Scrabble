// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Core.Tests
{
    using System.Collections.Generic;
    using Brisk;
    using Brook;
    using Brook.Octet;
    using Channels;
    using Coherence.Common;
    using Coherence.Common.Tests;
    using Coherence.ProtocolDef;
    using Coherence.Tests;
    using Connection;
    using Entities;
    using NUnit.Framework;
    using Serializer;
    using SimulationFrame;

    public class OutOrderedNetworkChannelTests : CoherenceTest
    {
        private OutOrderedNetworkChannel channel;
        private HashSet<Entity> ackedEntities;
        private Dictionary<Entity, HashSet<uint>> ackedComponentsPerEntity;
        private readonly AbsoluteSimulationFrame simulationFrame = new()
        {
            Frame = 1
        };
        private readonly Vector3d floatingOrigin = new Vector3d(0, 0, 0);

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();

            channel = new OutOrderedNetworkChannel(null, logger);
            ackedEntities = new HashSet<Entity>();
            ackedComponentsPerEntity = new Dictionary<Entity, HashSet<uint>>();
        }

        [Test]
        public void ShouldNotSend_WithoutQueuedCommands()
        {
            var (result, _) = SerializeTick();

            Assert.That(result, Is.Null);
        }

        [Test]
        public void ShouldNotSend_UnackedMessagesTwice()
        {
            var entityID = new Entity((Entities.Index)1, 0, false);
            channel.PushCommand(CreateTestCommand(), false);
            channel.PushCommand(CreateTestCommand(), false);

            var (res1, _) = SerializeTick();
            Assert.That(res1.MessagesSent.Count, Is.EqualTo(2));

            var (res2, _) = SerializeTick();
            Assert.That(res2, Is.Null);
        }

        [Test]
        public void ShouldResend_OnFailedDelivery()
        {
            var entityID = new Entity((Entities.Index)1, 0, false);
            channel.PushCommand(CreateTestCommand(), false);
            channel.PushCommand(CreateTestCommand(), false);

            var (res1, _) = SerializeTick();
            Assert.That(res1.MessagesSent.Count, Is.EqualTo(2));

            HandleAck(false);

            var (res2, _) = SerializeTick();
            Assert.That(res2.MessagesSent.Count, Is.EqualTo(2));
        }

        [TestCase(true)]
        [TestCase(false)]
        [Description("Tests that MarkAsSent and OnDeliveryInfo don't throw if there was nothing even serialized.")]
        public void MarkAsSent_WhenNotSerialzed_DoesntThrow(bool wasDelivered)
        {
            var sequenceID = 1u;

            channel.MarkAsSent(sequenceID);

            channel.OnDeliveryInfo(sequenceID, wasDelivered, ref ackedEntities, ref ackedComponentsPerEntity);
        }

        private (OrderedChannelSerializationResult, OutOctetStream) SerializeTick()
        {
            var octetStream = new OutOctetStream(Brisk.DefaultMTU);
            var stream = new OutBitStream(octetStream);
            var ctx = new SerializerContext<IOutBitStream>(stream, false, logger);

            channel.Serialize(ctx, simulationFrame, floatingOrigin, false, ackedEntities);

            stream.Flush();

            _ = channel.MarkAsSent(0);

            return (channel.LastSerializationResult as OrderedChannelSerializationResult, octetStream);
        }

        private void HandleAck(bool delivered) =>
            channel.OnDeliveryInfo(0, delivered, ref ackedEntities, ref ackedComponentsPerEntity);

        private CommandData CreateTestCommand()
        {
            var entityID = new Entity((Entities.Index)1, 0, false);
            return AuthorityRequestCommand.Create(TestSchema.DataFactory, entityID, MessageTarget.StateAuthorityOnly,new ClientID(1), AuthorityType.State);
        }
    }
}
