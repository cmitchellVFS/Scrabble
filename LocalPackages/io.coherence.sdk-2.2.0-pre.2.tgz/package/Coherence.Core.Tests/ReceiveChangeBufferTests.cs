﻿// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using Coherence.Common.Tests;
    using Coherence.Entities.Tests;
    using Coherence.Serializer;
    using Coherence.Tests;
    using Common;
    using Entities;
    using Moq;
    using NUnit.Framework;
    using ProtocolDef;

    public class ReceiveChangeBufferTests : CoherenceTest
    {
        private PooledSchemaDataFactory schemaDataFactory;
        private ReceiveChangeBuffer changeBuffer;
        private Mock<IDateTimeProvider> dateTimeProviderMock;
        private Mock<IEntityRegistry> entityRegistryMock;
        private List<IncomingEntityUpdate> updates;
        private Queue<CommandData> commands;
        private Queue<InputData> inputs;

        private Entity entity1 = new Entity((Entities.Index)101, 0, false);
        private Entity entity2 = new Entity((Entities.Index)102, 0, false);

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();

            schemaDataFactory = new PooledSchemaDataFactory(TestSchema.Definition, threadSafe: false, poolInputs: true);
            entityRegistryMock = new Mock<IEntityRegistry>();
            dateTimeProviderMock = new Mock<IDateTimeProvider>();
            _ = dateTimeProviderMock.Setup(m => m.UtcNow).Returns(() => DateTime.UtcNow);

            changeBuffer = new ReceiveChangeBuffer(entityRegistryMock.Object, logger,
                dateTimeProviderMock.Object);

            updates = new List<IncomingEntityUpdate>();
            commands = new Queue<CommandData>();
            inputs = new Queue<InputData>();
        }

        [TearDown]
        public override void TearDown()
        {
            foreach (var update in updates)
            {
                update.Dispose();
            }

            foreach (var cmd in commands)
            {
                cmd.Dispose();
            }

            foreach (var input in inputs)
            {
                input.Dispose();
            }

            changeBuffer.Clear();
            schemaDataFactory.AssertNoLeaks();

            base.TearDown();
        }

        [Test]
        [Description("Verifies that the TryPushUpdatesInto doesn't return a partial update - " +
                     "an update that was added to the buffer before a create for this entity.")]
        public void UpdateIsHeldBackIfTheresNoCreate()
        {
            // Arrange
            var partialUpdate = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update)
                .Components(c => c.AddGlobal())
                .Build();

            // Act
            changeBuffer.AddChange(partialUpdate);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Is.Empty);
        }

        [Test]
        [Description("Verifies that the TryPushUpdatesInto returns an update if entity is known.")]
        public void UpdateProcessForKnown()
        {
            // Arrange
            var update = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update)
                .Components(c => c.AddGlobal())
                .Build();

            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);

            // Act
            changeBuffer.AddChange(update);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(1));
            Assert.That(updates[0].Meta.Operation, Is.EqualTo(EntityOperation.Update));
        }

        [Test]
        [Description("Verifies that create on its own is never held back.")]
        public void CreateNeverHeldBack()
        {
            // Arrange
            var update = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Build();

            // Act
            changeBuffer.AddChange(update);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(1));
            Assert.That(updates[0].Meta.Operation, Is.EqualTo(EntityOperation.Create));
        }

        [Test]
        [Description("Verifies that create that isn't resovable is held back.")]
        public void CreateUnresovableHeldBack()
        {
            // Arrange
            var update = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Build();

            // Act
            changeBuffer.AddChange(update);
            TakeUpdates(updates);

            // Assert
            Assert.That(updates, Is.Empty);
        }

        [Test]
        [Description("Verifies that destroy on its own is never held back.")]
        public void DestroyNeverHeldBack()
        {
            // Arrange
            var update = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Destroy)
                .Build();

            MakeEntityKnown(update.Entity);

            // Act
            changeBuffer.AddChange(update);
            TakeUpdates(updates);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(1));
            Assert.That(updates[0].Meta.Operation, Is.EqualTo(EntityOperation.Destroy));
        }

        [Test]
        [Description("Verifies that if we add an update followed by a create " +
                     "we can take both from the buffer (they are not held back).")]
        public void CreateAddedAfterUpdateCanBeTaken()
        {
            // Arrange
            var partialUpdate = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update)
                .Components(c => c.AddGlobal())
                .Build();

            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.AddPosition())
                .Build();

            // Act
            changeBuffer.AddChange(partialUpdate);
            changeBuffer.AddChange(create);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(1));
            Assert.That(updates[0].Components.HasComponent(GlobalComponent.ComponentID));
            Assert.That(updates[0].Components.HasComponent(WorldPositionComponent.ComponentID));
        }

        [Test]
        [Description("Verifies that if we add a create followed by an update " +
                     "we can take both from the buffer (they are not held back).")]
        public void UpdateAddedAfterCreateCanBeTaken()
        {
            // Arrange
            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.AddPosition())
                .Build();

            var update = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update)
                .Components(c => c.AddGlobal())
                .Build();

            // Act
            changeBuffer.AddChange(create);
            changeBuffer.AddChange(update);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(1));
            Assert.That(updates[0].Components.HasComponent(GlobalComponent.ComponentID));
            Assert.That(updates[0].Components.HasComponent(WorldPositionComponent.ComponentID));
        }

        [Test]
        [Description("Verifies that if buffer receives a create request with component A, " +
                     "followed by a remove request for A, followed by resent create but " +
                     "with recreated component A, the merged result contains component A.")]
        public void RemoveFollowedByCreateMergesCorrectly()
        {
            // Arrange
            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.AddGlobal())
                .Build();

            var remove = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.RemoveGlobal())
                .Build();

            var resentCreate = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.AddGlobal())
                .Build();

            // Act
            changeBuffer.AddChange(create);
            changeBuffer.AddChange(remove);
            changeBuffer.AddChange(resentCreate);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(1));
            Assert.That(updates[0].Components.HasComponent(GlobalComponent.ComponentID));
        }

        [Test]
        [Description("Verifies that if buffer receives a destroy entity request " +
                     "while there's a pending create request for this entity, " +
                     "both are simply removed.")]
        public void DestroyMergedOnTopOfCreate()
        {
            // Arrange
            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Build();

            var destroy = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Destroy)
                .Build();

            // Act
            changeBuffer.AddChange(create);
            changeBuffer.AddChange(destroy);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity);

            // Assert
            Assert.That(updates, Is.Empty);
        }

        [Test]
        [Description("Verifies that commands and inputs targeting non-existing entity " +
                     "are held in the buffer until that entity arrives.")]
        public void HoldsOnToCommandsAndInputsForUnknownEntities()
        {
            // Arrange
            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All));
            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All, 0, false));

            // Act
            TakeCommands(commands);
            TakeInputs(inputs);

            // Assert
            Assert.That(commands, Is.Empty);
            Assert.That(inputs, Is.Empty);
        }

        [Test]
        [Description("Verifies that commands referencing unknown entities are held in the buffer " +
                     "until that entity arrives.")]
        public void HoldsOnToCommandsReferencingUnknownEntities()
        {
            // Arrange
            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);
            MakeEntityKnown(entity2);

            changeBuffer.AddCommand(EntityRefsCommand.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All, entity1, entity2));

            // Act
            TakeCommands(commands);

            // Assert
            Assert.That(commands, Is.Empty);

            // Arrange - make entity1 known
            MakeEntityKnown(entity1);

            // Act
            TakeCommands(commands);

            // Assert
            Assert.That(commands, Has.Count.EqualTo(1));
        }

        [Test]
        [Description("Verifies that authority only commands targeting non-authoritative entity " +
                     "are held in the buffer until authority is obtained.")]
        public void HoldsOnToAuthorityOnlyCommandsTargetingNonAuthoritativeEntity()
        {
            // Arrange
            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);
            SetEntityAuthority(IncomingEntityUpdateBuilder.DefaultEntity, AuthorityType.None);

            changeBuffer.AddCommand(ByteArraysCommand.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.StateAuthorityOnly, null, null, null, null, null, null));

            // Act
            TakeCommands(commands);

            // Assert
            Assert.That(commands, Is.Empty);

            // Arrange - give authority
            SetEntityAuthority(IncomingEntityUpdateBuilder.DefaultEntity, AuthorityType.State);

            // Act
            TakeCommands(commands);

            // Assert
            Assert.That(commands, Has.Count.EqualTo(1));
        }

        [Test]
        [Description("Verifies that commands and inputs targeting existing entity " +
                     "can be taken from the buffer.")]
        public void PassCommandsAndInputsForKnownEntities()
        {
            // Arrange
            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);

            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All));
            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All, 0, false));

            // Act
            TakeCommands(commands);
            TakeInputs(inputs);

            // Assert
            Assert.That(commands, Has.Count.EqualTo(1));
            Assert.That(inputs, Has.Count.EqualTo(1));
        }

        [Test]
        [Description("Verifies that inputs and commands that reference remotely created then locally destroyed entity " +
            "are held back.")]
        public void HoldsOnToCommandsReferencingRemotelyCreatedButLocallyDestroyedEntity()
        {
            // Arrange - remotely created
            var entity = new Entity((Entities.Index)10, 0, false);

            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create, entity).Build();

            changeBuffer.AddChange(create);

            TakeUpdates(updates, entity);

            MakeEntityKnown(entity);

            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, entity, MessageTarget.All));
            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, entity, MessageTarget.All, 0, false));

            // Act
            TakeCommands(commands);
            TakeInputs(inputs);

            // Assert
            Assert.That(commands, Has.Count.EqualTo(1));
            Assert.That(inputs, Has.Count.EqualTo(1));

            // Clean up
            foreach (var update in updates)
            {
                update.Dispose();
            }
            foreach (var cmd in commands)
            {
                cmd.Dispose();
            }
            foreach (var input in inputs)
            {
                input.Dispose();
            }

            // Clear
            updates.Clear();
            commands.Clear();
            inputs.Clear();

            // Arrange - locally destroyed
            MakeEntityUnknown(entity);

            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, entity, MessageTarget.All));
            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, entity, MessageTarget.All, 0, false));

            // Act
            TakeCommands(commands);
            TakeInputs(inputs);

            // Assert
            Assert.That(commands, Is.Empty);
            Assert.That(inputs, Is.Empty);
        }

        [Test]
        [Description("Verifies that commands and inputs are dropped " +
                     "when a destroy request is added to the buffer.")]
        public void CommandsAndInputsDroppedWhenDestroyArrives()
        {
            // Arrange
            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);

            var destroy = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Destroy)
                .Build();

            // Act
            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All));
            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All, 0, false));
            changeBuffer.AddChange(destroy);

            TakeCommands(commands);
            TakeInputs(inputs);

            // Assert
            Assert.That(commands, Is.Empty);
            Assert.That(inputs, Is.Empty);
        }

        [Test]
        [Description("Verifies that commands entity fields are nulled when " +
            "referenced entity destroy request is added to the buffer.")]
        public void CommandsEntityRefsNulledWhenDestroyArrivesForReferencedEntity()
        {
            // Arrange
            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);
            MakeEntityKnown(entity1);
            MakeEntityKnown(entity2);

            var destroy = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Destroy, entity1)
                .Build();

            // Act
            changeBuffer.AddCommand(EntityRefsCommand.Create(schemaDataFactory, IncomingEntityUpdateBuilder.DefaultEntity, MessageTarget.All, entity1, entity2));
            changeBuffer.AddChange(destroy);

            TakeCommands(commands);

            // Assert
            Assert.That(commands, Has.Count.EqualTo(1));

            var command = EntityRefsCommand.From(commands.Peek());
            Assert.That(command.EntityRef1, Is.EqualTo(Entity.InvalidRelative));
        }

        [Test]
        [Description("Verifies that a change that contains a reference to an entity " +
                     "that is not known is held (can't be taken).")]
        public void ChangeIsHeldIfItHasUnresolvedReferences()
        {
            // Arrange
            MakeEntityKnown(IncomingEntityUpdateBuilder.DefaultEntity);
            var unknownEntity = new Entity((Entities.Index)20, 0, false);

            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.AddConnectedEntity(unknownEntity))
                .Build();

            // Act
            changeBuffer.AddChange(create);
            TakeUpdates(updates);

            // Assert
            Assert.That(updates, Is.Empty);
        }

        [Test]
        [Description("Verifies that a change that contains a reference to an entity can be taken " +
                     "from the buffer once that entity reference gets resolved (is mapped).")]
        public void ChangeIsReleasedWhenReferencesGetResolved()
        {
            // Arrange
            var referencedEntity = new Entity((Entities.Index)20, 0, false);

            var create = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create)
                .Components(c => c.AddConnectedEntity(referencedEntity))
                .Build();

            var referencedCreate = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create, referencedEntity)
                .Build();

            // Act
            changeBuffer.AddChange(create);
            changeBuffer.AddChange(referencedCreate);
            TakeUpdates(updates, IncomingEntityUpdateBuilder.DefaultEntity, referencedEntity);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(2));
            Assert.That(updates, Has.Exactly(1).Matches<IncomingEntityUpdate>(update => update.Entity == referencedEntity));
            Assert.That(updates,
                Has.Exactly(1).Matches<IncomingEntityUpdate>(update => update.Entity == IncomingEntityUpdateBuilder.DefaultEntity));
        }

        [Test]
        [Description("Verifies that inputs and commands for not existing entities are eventually dropped.")]
        public void InputsAndCommandsExpire()
        {
            // Arrange
            var entityA = new Entity((Entities.Index)1, 0, false);

            DateTime now = new DateTime(2000, 1, 1, 12, 1, 1);
            _ = dateTimeProviderMock.Setup(m => m.UtcNow).Returns(now);

            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, entityA, MessageTarget.All, 0, false));
            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, entityA, MessageTarget.All));

            // Act
            _ = dateTimeProviderMock.Setup(m => m.UtcNow).Returns(now + ReceiveChangeBuffer.MessageTTL);

            TakeInputs(inputs);
            TakeCommands(commands);

            // Assert
            MakeEntityKnown(entityA);
            TakeInputs(inputs);
            TakeCommands(commands);

            Assert.That(inputs, Is.Empty);
            Assert.That(commands, Is.Empty);
        }

        [Test]
        [Description(
            "Verifies that inputs and commands for not existing entities are not dropped before reaching TTL.")]
        public void InputsAndCommandsDoNotExpireEarly()
        {
            // Arrange
            var entityA = new Entity((Entities.Index)1, 0, false);

            DateTime now = new DateTime(2000, 1, 1, 12, 1, 1);
            _ = dateTimeProviderMock.Setup(m => m.UtcNow).Returns(now);

            changeBuffer.AddInput(BoolInput.Create(schemaDataFactory, entityA, MessageTarget.All, 0, false));
            changeBuffer.AddCommand(AdoptOrphanCommand.Create(schemaDataFactory, entityA, MessageTarget.All));

            // Act
            _ = dateTimeProviderMock.Setup(m => m.UtcNow)
                .Returns(now + ReceiveChangeBuffer.MessageTTL - TimeSpan.FromMilliseconds(1f));

            TakeInputs(inputs);
            TakeCommands(commands);

            // Assert
            MakeEntityKnown(entityA);
            TakeInputs(inputs);
            TakeCommands(commands);

            Assert.That(inputs, Is.Not.Empty);
            Assert.That(commands, Is.Not.Empty);
        }

        [Test]
        [Description("Verifies that changes are correctly sorted by operation and then by ref count.")]
        public void ChangesAreSortedByOperationAndRefCount()
        {
            // Arrange
            var entityA = new Entity((Entities.Index)1, 0, false);
            var entityB = new Entity((Entities.Index)2, 0, false);
            var entityC = new Entity((Entities.Index)3, 0, false);
            var entityD = new Entity((Entities.Index)4, 0, false);
            var entityE = new Entity((Entities.Index)5, 0, false);
            var entityF = new Entity((Entities.Index)6, 0, false);
            var entityG = new Entity((Entities.Index)7, 0, false);

            var createA = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create, entityA)
                .Components(c => c.AddGlobal())
                .Build();

            var createB = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create, entityB)
                .Components(c => c.AddGlobal())
                .Build();

            var createC = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Create, entityC)
                .Components(c => c.AddGlobal().AddConnectedEntity(entityB))
                .Build();

            var updateD = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update, entityD)
                .Components(c => c.AddGlobal())
                .Build();

            var updateE = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update, entityE)
                .Components(c => c.AddGlobal().AddConnectedEntity(entityA))
                .Build();

            var updateF = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Update, entityF)
                .Components(c => c.AddGlobal())
                .Build();

            var destroyG = new IncomingEntityUpdateBuilder(schemaDataFactory, EntityOperation.Destroy, entityG)
                .Build();

            MakeEntityKnown(entityD);
            MakeEntityKnown(entityE);
            MakeEntityKnown(entityF);
            MakeEntityKnown(entityG);

            // Act
            changeBuffer.AddChange(updateE);
            changeBuffer.AddChange(createA);
            changeBuffer.AddChange(createC);
            changeBuffer.AddChange(updateD);
            changeBuffer.AddChange(createB);
            changeBuffer.AddChange(updateF);
            changeBuffer.AddChange(destroyG);

            TakeUpdates(updates, entityA, entityB, entityC, entityD, entityE, entityF);

            // Assert
            Assert.That(updates, Has.Count.EqualTo(7));
            Assert.That(updates[0].Meta.Operation, Is.EqualTo(EntityOperation.Create));
            Assert.That(updates[1].Meta.Operation, Is.EqualTo(EntityOperation.Create));
            Assert.That(updates[2].Meta.Operation, Is.EqualTo(EntityOperation.Create));
            Assert.That(updates[3].Meta.Operation, Is.EqualTo(EntityOperation.Destroy));
            Assert.That(updates[4].Meta.Operation, Is.EqualTo(EntityOperation.Update));
            Assert.That(updates[5].Meta.Operation, Is.EqualTo(EntityOperation.Update));
            Assert.That(updates[6].Meta.Operation, Is.EqualTo(EntityOperation.Update));

            Assert.That(updates[0].Entity, Is.EqualTo(entityA).Or.EqualTo(entityB)); // entityA and entityB can be in any order
            Assert.That(updates[1].Entity, Is.EqualTo(entityA).Or.EqualTo(entityB)); // because they have same ref count
            Assert.That(updates[2].Entity, Is.EqualTo(entityC));
            Assert.That(updates[3].Entity, Is.EqualTo(entityG));
            Assert.That(updates[4].Entity, Is.EqualTo(entityD).Or.EqualTo(entityF)); // entityD and entityF can be in any order
            Assert.That(updates[5].Entity, Is.EqualTo(entityD).Or.EqualTo(entityF)); // because they have same ref count
            Assert.That(updates[6].Entity, Is.EqualTo(entityE));
        }

        private void MakeEntityKnown(Entity entity)
        {
            _ = entityRegistryMock.Setup(m => m.EntityExists(entity)).Returns(true);
        }

        private void SetEntityAuthority(Entity entity, AuthorityType authority)
        {
            _ = entityRegistryMock.Setup(m => m.HasAuthorityOverEntity(entity, It.IsAny<AuthorityType>()))
                .Returns<Entity, AuthorityType>((e, authorityType) => authority.Contains(authorityType));
        }

        private void MakeEntityUnknown(Entity entity)
        {
            _ = entityRegistryMock.Setup(m => m.EntityExists(entity)).Returns(false);
        }

        private void TakeUpdates(List<IncomingEntityUpdate> buffer, params Entity[] resolvableEntities)
        {
            changeBuffer.TakeUpdates(buffer, new List<Entity>(resolvableEntities));
        }
        private void TakeCommands(Queue<CommandData> buffer)
        {
            changeBuffer.TakeCommands(buffer);
        }

        private void TakeInputs(Queue<InputData> buffer)
        {
            changeBuffer.TakeInputs(buffer);
        }

    }
}
