// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Common.Tests
{
    using Coherence.ProtocolDef;

    public static class TestSchema
    {
        private static ProtocolDefinition definition;
        private static ISchemaDataFactory dataFactory;

        public static ProtocolDefinition Definition => definition;
        public static ISchemaDataFactory DataFactory => dataFactory;

        static TestSchema()
        {
            definition = ProtocolDefinition.LoadFromPath("../sdk/Coherence.Common.Tests/test.schema", includeRSSchema: true);
            dataFactory = new DefaultSchemaDataFactory(definition);
        }
    }
}
