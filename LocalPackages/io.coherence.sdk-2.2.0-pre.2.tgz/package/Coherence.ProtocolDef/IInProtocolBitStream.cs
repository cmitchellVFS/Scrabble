// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.ProtocolDef
{
    using Brook;
    using Entities;
    using System.Numerics;
    using Coherence.Common;
    using Coherence.Connection;

    public interface IInProtocolBitStream
    {
        IInBitStream BitStream { get; }

        uint ReadBits(int count);
        byte ReadByte();
        sbyte ReadSByte();
        short ReadShort();
        ushort ReadUShort();
        char ReadChar();
        int ReadIntegerRange(int bitCount, int offset);
        uint ReadUIntegerRange(int bitCount, uint offset);
        long ReadLong();
        ulong ReadULong();
        double ReadDouble();
        float ReadFloat(in FieldMeta meta);
        Vector2 ReadVector2(in FieldMeta meta);
        Vector3 ReadVector3(in FieldMeta meta);
        Vector3d ReadVector3d();
        Vector4 ReadVector4(in FieldMeta meta);
        Vector4 ReadColor(in FieldMeta meta);
        Quaternion ReadQuaternion(int bitsPerComponent);
        string ReadString();
        bool ReadBool();
        int ReadEnum();
        bool ReadMask();
        uint ReadMaskBits(uint numBits);
        Entity ReadEntity();
        byte[] ReadBytes();
        ClientID ReadClientID();
    }
}
