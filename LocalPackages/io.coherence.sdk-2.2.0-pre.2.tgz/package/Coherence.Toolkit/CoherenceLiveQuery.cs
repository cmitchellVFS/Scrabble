// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Toolkit
{
    using System;
    using Coherence.ProtocolDef;
    using Entities;
    using UnityEngine;
    using UnityEngine.Serialization;

    /// <summary>
    /// Filters what entities are replicated, based on position.
    /// </summary>
    /// <remarks>
    /// This component is required for entities to get replicated.
    ///
    /// When the <see cref="GameObject"/> moves, the associated <see cref="CoherenceLiveQuery"/> moves accordingly.
    ///
    /// Using a live query is a great optimization if there's lots of entities,
    /// but only the few contained within the live query area are relevant.
    /// </remarks>
    [AddComponentMenu("coherence/Queries/Coherence Live Query")]
    [DefaultExecutionOrder(ScriptExecutionOrder.CoherenceQuery)]
    [NonBindable]
    [HelpURL("https://docs.coherence.io/v/2.2/manual/components/coherence-live-query")]
    [CoherenceDocumentation(DocumentationKeys.LiveQuery)]
    public sealed class CoherenceLiveQuery : CoherenceQuery
    {
        internal static class Properties
        {
            public const string Extent = nameof(extent);
            public const string Buffer = nameof(buffer);
            public const string ExtentUpdateThreshold = nameof(extentUpdateThreshold);
            public const string DistanceUpdateThreshold = nameof(distanceUpdateThreshold);
        }

        // for components, we don't expose direct creation of instances - add as component instead
        private CoherenceLiveQuery()
        {
        }

        [FormerlySerializedAs("radius")]
        [SerializeField]
        [Min(1)]
        private float extent;

        /// <summary>
        /// Defines the active area of the live query.
        /// </summary>
        /// <remarks>
        /// Half the length of the cube's edges.
        /// Set to 0 to consider all entities within the scene, independently of their position.
        /// </remarks>
        public float Extent
        {
            get => extent;
            set => extent = value;
        }

        [SerializeField]
        [Min(0)]
        [Tooltip("Additional extent radius buffer for entity deletion outside of extent to prevent hysteresis.")]
        private float buffer;

        /// <summary>
        /// Defines the buffer area of the live query.
        /// </summary>
        /// <remarks>
        /// To prevent entity create / destroy hysteresis, use the buffer to extend the range of the
        /// query for destroying entities that exit the primary extent.
        /// </remarks>
        public float Buffer
        {
            get => buffer;
            set => buffer = value;
        }

        /// <inheritdoc cref="Extent"/>
        [Deprecated("21/11/2024", 1, 4, 0)]
        [Obsolete("Use Extent instead.")]
        public float radius
        {
            get => Extent;
            set => Extent = value;
        }

        [SerializeField]
        [Tooltip("Difference in the magnitude of the extent at which to trigger an update on the live query. Only relevant when the area is constrained.")]
        [Min(0)]
        private float extentUpdateThreshold = .01f;

        /// <summary>
        /// Magnitude difference at which to trigger an update on the live query.
        /// </summary>
        /// <remarks>
        /// This can be useful if you're resizing the live query area gradually,
        /// and want to optimize the number of times the query needs updating.
        /// </remarks>
        public float ExtentUpdateThreshold
        {
            get => extentUpdateThreshold;
            set => extentUpdateThreshold = value;
        }

        [SerializeField]
        [Tooltip("Distance since last update at which an update on the live query is triggered.")]
        [Min(0)]
        private float distanceUpdateThreshold = .01f;

        /// <summary>
        /// Distance since last update at which an update on the live query is triggered.
        /// </summary>
        /// <remarks>
        /// This can be useful if you're moving the live query constantly,
        /// and want to optimize the number of times the query needs updating.
        /// </remarks>
        public float DistanceUpdateThreshold
        {
            get => distanceUpdateThreshold;
            set => distanceUpdateThreshold = value;
        }

        private Vector3 lastPosition;
        private float lastExtent;
        private float lastBuffer;
        private Transform cachedTransform;
        private bool queryIsAdded;

        protected override void Reset()
        {
            base.Reset();

            extent = 0f;
            extentUpdateThreshold = .01f;
            distanceUpdateThreshold = .01f;
        }

        protected override void Awake()
        {
            cachedTransform = transform;
            lastPosition = cachedTransform.position;
            lastExtent = Extent;
            lastBuffer = Buffer;

            base.Awake();
        }

        private bool IsExtentPastThreshold => Mathf.Abs(extent - lastExtent) > extentUpdateThreshold;
        private bool IsBufferPastThreshold => Mathf.Abs(buffer - lastBuffer) > extentUpdateThreshold;
        private bool IsDistancePastThreshold => (cachedTransform.position - lastPosition).sqrMagnitude > distanceUpdateThreshold * distanceUpdateThreshold;
        private bool IsPastAnyThreshold => IsDistancePastThreshold || IsExtentPastThreshold || IsBufferPastThreshold;
        private bool IsChangingMode => extent <= 0 && lastExtent > 0 || extent > 0 && lastExtent <= 0;

        protected override bool NeedsUpdate => IsChangingMode || IsPastAnyThreshold;

        protected override void UpdateQuery(bool queryActive = true)
        {
            if (queryActive)
            {
                var position = cachedTransform.position;

                Client.UpdateComponents(EntityID, new ComponentData[]
                {
                    WorldPositionQueryComponent.Create(Client.SchemaDataFactory, position.ToCoreVector3(), Extent, Buffer)
                });
                queryIsAdded = true;

                lastPosition = position;
                lastExtent = Extent;
            }
            else
            {
                if (EntityID == Entity.InvalidRelative || !queryIsAdded)
                {
                    return;
                }

                Client.RemoveComponents(EntityID, new uint[]
                {
                    WorldPositionQueryComponent.ComponentID
                });
                queryIsAdded = false;

                lastExtent = -1;
            }
        }
    }
}
