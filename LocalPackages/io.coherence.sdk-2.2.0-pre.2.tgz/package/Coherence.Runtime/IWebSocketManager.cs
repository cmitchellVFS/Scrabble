// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence.Runtime
{
    using System;
    using System.Collections.Generic;
    using Cloud;

    internal interface IWebSocketManager : IDisposable
    {
        bool Enabled { get; }
        bool IsConnected();
        event Action OnConnect;
        event Action OnDisconnect;
        event Action OnWebSocketFail;
        event Action<string> OnWebSocketParametersNotValid;
        bool AddPushCallback(string requestID, OnRequest callback);
        void Connect();
        void SendRequest(string path, string method, string body, Dictionary<string, string> headers, string sessionToken, OnRequest callback);
        void Update();
    }
}
