// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence
{
    using Common;
    using System;
    using Transport;
    using UnityEngine;
    using UnityEngine.Serialization;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
#if UNITY_EDITOR
    using UnityEditor;
#endif

    [PreloadedSingleton]
    public class RuntimeSettings : PreloadedSingleton<RuntimeSettings>, IRuntimeSettings
    {
        public bool IsWebGL => Application.platform == RuntimePlatform.WebGLPlayer;
        public string ApiEndpoint => playApiEndpoint;
        public string WebSocketEndpoint => webSocketEndpoint;
        public string LocalHost => localHost;
        public int LocalWorldUDPPort => localWorldUDPPort;
        public int LocalWorldWebPort => localWorldWebPort;
        public int RemoteWebPort => remoteWebPort;
        public int LocalRoomsUDPPort => localRoomsUDPPort;
        public int LocalRoomsWebPort => localRoomsWebPort;
        public int APIPort => apiPort;
        public int WorldsAPIPort => worldsAPIPort;
        public int PingPort => pingPort;
        public bool UseDebugStreams => useDebugStreams;
        public AdvancedSettings Advanced => advancedSettings;
        public Log.Settings LogSettings => logSettings;
        public bool SimulatorLockTargetFramerate
        {
            get => simulatorLockTargetFramerate;
            set => simulatorLockTargetFramerate = value;
        }
        public int SimulatorTargetFramerate
        {
            get => simulatorTargetFramerate;
            set => simulatorTargetFramerate = value;
        }

        public string RuntimeKey
        {
            get => runtimeKey;
            internal set => runtimeKey = value;
        }

        public string SimulatorSlug
        {
            get => simulatorSlug;
            set => simulatorSlug = value;
        }

        public string SchemaID
        {
            get => schemaID;
            internal set => schemaID = value;
        }

        internal VersionInfo VersionInfo
        {
            get => versionInfo;
            set => versionInfo = value;
        }

        [Obsolete("Deprecated; ProjectSettings.OrganizationId should be used instead.")]
        [Deprecated("05/2025", 1, 7, 2, Reason = "Replaced by ProjectSettings.OrganizationId.")]
        public string OrganizationID
        {
            get => organizationID;
            internal set => organizationID = value;
        }

        [Obsolete("Deprecated; ProjectSettings.OrganizationName should be used instead.")]
        [Deprecated("05/2025", 1, 7, 2, Reason = "Replaced by ProjectSettings.OrganizationName.")]
        public string OrganizationName
        {
            get => organizationName;
            internal set => organizationName = value;
        }

        public string ProjectID
        {
            get => projectID;
            internal set => projectID = value;
        }

        public string ProjectName
        {
            get => projectName;
            internal set => projectName = value;
        }

        public TransportType TransportType
        {
            get => transportType;
            internal set => transportType = value;
        }

        public IEnumerable<SchemaAsset> DefaultSchemas
        {
            get => schemas.Where(s => s != null);
        }

        public string CombinedSchemaText { get; private set; }

        public bool DisableKeepAlive
        {
            get { return disableKeepAlive; }
            set { disableKeepAlive = value; }
        }

        public string RsVersion => string.IsNullOrEmpty(RsVersionOverride)
            ? VersionInfo ? VersionInfo.Engine : "v0.0.0"
            : RsVersionOverride;
        private string RsVersionOverride => rsVersionOverride;

        public string SdkVersion => VersionInfo
            ? !string.IsNullOrEmpty(SdkVersionBuildMetadata) ? VersionInfo.Sdk + SdkVersionBuildMetadata : VersionInfo.Sdk
            : "0.0.0";

        internal string SdkVersionBuildMetadata
        {
            get => sdkVersionBuildMetadata;
            set => sdkVersionBuildMetadata = value;
        }

        /// <summary>
        /// Rate at which the Replication Server will send packets to clients.
        /// </summary>
        public int SendFrequency
        {
            get => sendFrequency;
        }

        /// <summary>
        /// Rate at which the Replication Server wants to receive packets from any client.
        /// </summary>
        /// <remarks>
        /// Packets received faster will be dropped and the connection throttled.
        /// </remarks>
        public int RecvFrequency
        {
            get => recvFrequency;
        }

        [SerializeField] internal Log.Settings logSettings;
        [SerializeField] private string schemaID;
        [SerializeField] private VersionInfo versionInfo;
        [SerializeField] private string runtimeKey;
        [SerializeField] private string simulatorSlug;
        [SerializeField] private string localHost = Constants.localHost;

        [FormerlySerializedAs("localPort")]
        [Tooltip("Port at which the Replication Server will listen for world.")]
        [SerializeField] private int localWorldUDPPort = Constants.localWorldUDPPort;
        [Tooltip("Port at which the Replication Server will listen for world in web builds.")]
        [SerializeField] private int localWorldWebPort = Constants.localWorldWebPort;
        [SerializeField] private int remoteWebPort = Constants.remoteWebPort;
        [Tooltip("Port at which the Replication Server will listen for rooms.")]
        [SerializeField] private int localRoomsUDPPort = Constants.localRoomsUDPPort;
        [Tooltip("Port at which the Replication Server will listen for rooms in web builds.")]
        [SerializeField] private int localRoomsWebPort = Constants.localRoomsWebPort;

        [FormerlySerializedAs("roomsPort")]
        [SerializeField] private int apiPort = Constants.apiPort;
        [SerializeField] private int worldsAPIPort = Constants.worldsApiPort;
        [SerializeField] private int pingPort = Constants.pingPort;

        [Tooltip("Rate at which the Replication Server will send packets to clients.")]
        [SerializeField] private int sendFrequency = Constants.defaultSendFrequency;
        [Tooltip("Rate at which the Replication Server wants to receive packets from any client. Packets received faster will be dropped and the connection throttled.")]
        [SerializeField] private int recvFrequency = Constants.defaultRecvFrequency;

        [SerializeField] private bool useDebugStreams = false;
        [SerializeField] private string organizationID;
        [SerializeField] private string projectID;
        [SerializeField] private string projectName;
        [SerializeField] private string organizationName;
        [SerializeField] private TransportType transportType;
        [SerializeField] private AdvancedSettings advancedSettings;

        [Tooltip("Instead of the version specified in VersionInfo, use this version for the Replication Server. Example: master.")]
        [SerializeField] private string rsVersionOverride;

        [SerializeField, Tooltip("Can be overriden via --coherence-play-api-endpoint")]
        private string playApiEndpoint = Constants.apiEndpoint;

        [Tooltip("Obtained via --coherence-play-ws-endpoint. When empty, it's generated from Play API Endpoint")]
        private string webSocketEndpoint;

        private string sdkVersionBuildMetadata;
        [SerializeField] internal string storedSdkVersionBuildMetadata;

        [SerializeField]
        internal SchemaAsset[] schemas;

        [SerializeField]
        public SchemaAsset[] extraSchemas;

        // This should be of type Toolkit.CoherenceSync.AuthorityTransferType but we can't reference
        // Toolkit assembly from this assembly. So we just store it as an int :(
        // Default value of 2 is AuthorityTransferType.Steal
        [SerializeField]
        internal int defaultAuthorityTransferType = 2;

        [SerializeField]
        private bool simulatorLockTargetFramerate = true;
        [SerializeField, Min(0)]
        private int simulatorTargetFramerate = 30;

        [NonSerialized] private bool disableKeepAlive;

        internal static bool TryGet([NotNullWhen(true), MaybeNullWhen(false)] out RuntimeSettings runtimeSettings)
        {
            runtimeSettings = InstanceUnsafe;
            return runtimeSettings;
        }

        private void Reset()
        {
            localHost = Constants.localHost;
            localWorldUDPPort = Constants.localWorldUDPPort;
            localWorldWebPort = Constants.localWorldWebPort;
            localRoomsUDPPort = Constants.localRoomsUDPPort;
            localRoomsWebPort = Constants.localRoomsWebPort;
            apiPort = Constants.apiPort;
            pingPort = Constants.pingPort;
            remoteWebPort = Constants.remoteWebPort;
            playApiEndpoint = Constants.apiEndpoint;
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            if (!this)
            {
                return;
            }

#if UNITY_EDITOR
            hideFlags &= ~HideFlags.NotEditable;
#endif

            LoadCliOverrides();
            Init();
        }

        private void Init()
        {
            // Load a persisted SDK version build metadata if available. This is the case for builds made with a git-repo-based SDK.
            if (!string.IsNullOrEmpty(storedSdkVersionBuildMetadata))
            {
                sdkVersionBuildMetadata = storedSdkVersionBuildMetadata;
            }

            if (string.IsNullOrEmpty(playApiEndpoint))
            {
                playApiEndpoint = Constants.apiEndpoint;
            }
            else if (!playApiEndpoint.StartsWith("http://localhost:"))
            {
                playApiEndpoint = playApiEndpoint.Replace("http://", "https://");
            }

            if (string.IsNullOrEmpty(webSocketEndpoint))
            {
                webSocketEndpoint = playApiEndpoint.
                    Replace("http://", "ws://").
                    Replace("https://", "wss://");

                if (webSocketEndpoint.IndexOf("/play/api/v1", StringComparison.Ordinal) > -1)
                {
                    // OBSOLETE (not used in 0.9)
                    webSocketEndpoint = webSocketEndpoint.Replace("/play/api/v1", "/play/ws/v1");
                }
                else
                {
                    webSocketEndpoint = webSocketEndpoint + "/ws";
                }
            }

            CombinedSchemaText = schemas != null ? string.Join("\n", schemas.Select(s => s.raw)) : "";

            logSettings ??= new Log.Settings();
            Log.Settings.Provider ??= () => logSettings;
        }

        private static bool TryGetArg(string name, out string value)
        {
            var commandLineArgs = Environment.GetCommandLineArgs();
            var idx = Array.IndexOf(commandLineArgs, name);

            if (idx != -1 && commandLineArgs.Length > idx + 1)
            {
                value = commandLineArgs[idx + 1];
                return true;
            }
            else
            {
                value = string.Empty;
                return false;
            }
        }

        private void LoadCliOverrides()
        {
            if (TryGetArg("--coherence-play-ws-endpoint", out var wsEndpoint))
            {
                webSocketEndpoint = wsEndpoint;
            }

            if (TryGetArg("--coherence-play-api-endpoint", out var apiEndpoint))
            {
                playApiEndpoint = apiEndpoint;
            }
            else if (TryGetArg("--coherence-play-endpoint", out apiEndpoint))
            {
                playApiEndpoint = apiEndpoint + "/api/v1";
            }
        }

        public void SetApiEndpoint(string endpoint)
        {
            if (string.IsNullOrEmpty(endpoint))
            {
                playApiEndpoint = Constants.apiEndpoint;
                return;
            }

            playApiEndpoint = endpoint;
            Init();

#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssetIfDirty(this);
#endif
        }

        public void SetRuntimeKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return;
            }

            runtimeKey = key;
            Init();

#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssetIfDirty(this);
#endif
        }

        public void SetProjectID(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return;
            }

            projectID = id;
            Init();

#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssetIfDirty(this);
#endif
        }

        public void SetSchemaID(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return;
            }

            schemaID = id;
            Init();

#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssetIfDirty(this);
#endif
        }

        public void SetApiPort(int port)
        {
            if (port == 0)
            {
                apiPort = Constants.apiPort;
                return;
            }

            apiPort = port;
            Init();

#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssetIfDirty(this);
#endif
        }

        [Serializable]
        public class AdvancedSettings
        {
            internal static bool Enabled = Plugins.NativeUtils.ThreadResumerSettings.SteamDetected;
            public Plugins.NativeUtils.ThreadResumerSettings ThreadResumer = new();
        }

        /// <summary>
        /// Persists the SDK revision hash in serialized data.
        /// </summary>
        internal void Store()
        {
            storedSdkVersionBuildMetadata = sdkVersionBuildMetadata;
#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
#endif
        }

        /// <summary>
        /// Clears the stored SDK revision hash.
        /// </summary>
        internal void ClearStore()
        {
            storedSdkVersionBuildMetadata = null;
#if UNITY_EDITOR
            EditorUtility.SetDirty(this);
#endif
        }

        internal static class Property
        {
            public const string simulatorSlug = nameof(RuntimeSettings.simulatorSlug);
        }
    }
}
