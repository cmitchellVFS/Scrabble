﻿// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Coherence.Editor")]
[assembly: InternalsVisibleTo("Coherence.Toolkit")]
[assembly: InternalsVisibleTo("Coherence.Simulator")]
[assembly: InternalsVisibleTo("Coherence.Runtime")]
[assembly: InternalsVisibleTo("Coherence.Tests")]
[assembly: InternalsVisibleTo("Coherence.Tests.Editor")]
[assembly: InternalsVisibleTo("Coherence.IntegrationTests")]
[assembly: InternalsVisibleTo("Coherence.Toolkit.Tests")]
[assembly: InternalsVisibleTo("Coherence.Log.Tests")]
[assembly: InternalsVisibleTo("Coherence.Runtime.Tests")]
