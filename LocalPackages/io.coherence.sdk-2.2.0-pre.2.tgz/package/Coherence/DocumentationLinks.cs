// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

namespace Coherence
{
    using System;
    using System.Collections.Generic;

    internal static class DocumentationLinks
    {
        public static IEnumerable<DocumentationKeys> ActiveKeys => documentationLinks.Keys;

        // NOTE ending links with a '/' character triggers an additional a redirect that can make tests fail
        private static Dictionary<DocumentationKeys, string> documentationLinks = new()
        {
            { DocumentationKeys.DeveloperPortalOverview, "/hosting/coherence-cloud/online-dashboard" },
            { DocumentationKeys.ProjectSetup, "/getting-started/setup-a-project" },
            { DocumentationKeys.UploadSchema, "/getting-started/setup-a-project/test-in-the-cloud/deploy-replication-server#upload-schema" },
            { DocumentationKeys.PrefabSetup, "/getting-started/setup-a-project/prefab-setup" },
            { DocumentationKeys.SceneSetup, "/getting-started/setup-a-project/scene-setup" },
            { DocumentationKeys.Baking, "/manual/baking-and-code-generation" },
            { DocumentationKeys.Simulators, "/manual/simulation-server" },
            { DocumentationKeys.LocalServers, "/getting-started/setup-a-project/local-development" },
            { DocumentationKeys.AddBridge, "/getting-started/setup-a-project/scene-setup#id-1.-add-a-coherencebridge" },
            { DocumentationKeys.AddLiveQuery, "/getting-started/setup-a-project/scene-setup#id-2.-add-a-livequery" },
            { DocumentationKeys.Schemas, "/manual/advanced-topics/schema-explained" },
            { DocumentationKeys.RoomsAndWorlds, "/manual/replication-server/rooms-and-worlds" },
            { DocumentationKeys.CoherenceBridge, "/manual/components/coherence-bridge" },
            { DocumentationKeys.OnLiveQuerySynced, "/manual/components/coherence-bridge#onlivequerysynced" },
            { DocumentationKeys.CloudService, "/hosting/coherence-cloud" },
            { DocumentationKeys.SimFrame, "/manual/advanced-topics/competitive-games/simulation-frame" },
            { DocumentationKeys.ClientMessages, "/manual/client-connections" },
            { DocumentationKeys.ClientConnectionPrefabs, "/manual/client-connections#clientconnection-objects" },
            { DocumentationKeys.LiveQuery, "/manual/components/coherence-live-query" },
            { DocumentationKeys.Authority, "/manual/networking-state-changes/authority" },
            { DocumentationKeys.InputQueues, "/manual/networking-state-changes/authority/server-authoritative-setup" },
            { DocumentationKeys.CoherenceSync, "/manual/components/coherence-sync" },
            { DocumentationKeys.TagQuery, "/manual/components/coherence-tag-query" },
            { DocumentationKeys.SceneTransitioning, "/manual/scenes" },
            { DocumentationKeys.UnlockToken, "/manual/replication-server#unlock-token" },
            { DocumentationKeys.ReleaseNotes, "/support/release-notes" },
            { DocumentationKeys.Parenting, "/manual/networking-state-changes/parenting" },
            { DocumentationKeys.GettingStarted, "/getting-started/setup-a-project" },
            { DocumentationKeys.AutoSimulatorConnection, "/manual/simulation-server/client-vs-simulator-logic#connecting-simulators-automatically-to-rs-autosimulatorconnection-component" },
            { DocumentationKeys.Overview, "/overview" },
            { DocumentationKeys.MaxQueryCount, "/manual/replication-server#maximum-query-count-per-client" },
            { DocumentationKeys.CloudApi, "/hosting/coherence-cloud/coherence-cloud-apis" },
            { DocumentationKeys.ReplicationServerApi, "/manual/replication-server/replication-server-api" },
            { DocumentationKeys.GlobalQuery, "/manual/components/coherenceglobalquery" },
            { DocumentationKeys.ConnectionValidation, "/manual/simulation-server/advanced-simulator-authority#validating-client-connections" },
            { DocumentationKeys.PlayerAccounts, "/hosting/coherence-cloud/authentication-service-player-accounts" },
            { DocumentationKeys.CoherenceScene, "/manual/multiple-connections-within-a-game-instance" },
            { DocumentationKeys.CoherenceSceneLoader, "/manual/multiple-connections-within-a-game-instance" },
            { DocumentationKeys.CoherenceNode, "/manual/components/coherence-node" },
            { DocumentationKeys.Relays, "/hosting/client-hosting/implementing-client-hosting" },
            { DocumentationKeys.KnownIssues, "/support/known-issues" },
            { DocumentationKeys.CoherenceCloudLogin, "/manual/components/coherence-cloud-login" },
            { DocumentationKeys.Voice, "/manual/networking-voice" },
            { DocumentationKeys.UploadBuildToCoherence, "/manual/advanced-topics/team-workflows/continuous-integration-setup#game-build-pipeline" },
            { DocumentationKeys.SteamRelay, "/hosting/client-hosting/implementing-client-hosting/steam-relay" },
            { DocumentationKeys.PlayFabRelay, "/hosting/client-hosting/implementing-client-hosting/azure-playfab-relay" },
            { DocumentationKeys.EpicRelay, "/hosting/client-hosting/implementing-client-hosting/epic-online-services-eos-relay" },
            { DocumentationKeys.SampleScenes, "/getting-started/samples-and-tutorials/package-samples" },
            { DocumentationKeys.FirstSteps, "/getting-started/samples-and-tutorials/first-steps-tutorial" },
            { DocumentationKeys.Campfire, "/getting-started/samples-and-tutorials/campfire-project" },
            { DocumentationKeys.RoomsUI, "/getting-started/samples-and-tutorials/samples-connection-uis#rooms-connect-dialog" },
            { DocumentationKeys.WorldsUI, "/getting-started/samples-and-tutorials/samples-connection-uis#world-connect-dialog" },
            { DocumentationKeys.LobbiesUI, "/hosting/coherence-cloud/game-services/lobbies" },
            { DocumentationKeys.MatchmakingUI, "/hosting/coherence-cloud/game-services/lobbies" },
            { DocumentationKeys.SimulatorSlugs, "/manual/simulation-server/simulator-slugs" },
        };

        public static string GetDocsUrl(DocumentationKeys key = DocumentationKeys.None)
        {
            var path = string.Empty;

            if (key != DocumentationKeys.None && !documentationLinks.TryGetValue(key, out path))
            {
                throw new ArgumentException($"Key {key} not registered. Register it in '{nameof(DocumentationLinks)}.{nameof(documentationLinks)}'.", nameof(key));
            }

            return GetDocsBaseUrl() + path;
        }

        private static string GetDocsBaseUrl()
        {
            var settings = RuntimeSettings.Instance;
            var version = settings && settings.VersionInfo != null
                ? "/v/" + settings.VersionInfo.DocsSlug
                : string.Empty;
            return "https://docs.coherence.io" + version;
        }

        private static string GetUnpublishedDocsBaseUrl()
        {
            var settings = RuntimeSettings.Instance;
            var version = settings && settings.VersionInfo != null
                ? "/" + settings.VersionInfo.DocsSlug
                : string.Empty;
            return "https://docs-coherence.gitbook.io" + version;
        }
    }
}
