﻿// Copyright (c) coherence ApS.
// See the license file in the package root for more information.

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Coherence.Editor")]
[assembly: InternalsVisibleTo("Coherence.Toolkit")]
[assembly: InternalsVisibleTo("Coherence.Transport")]
[assembly: InternalsVisibleTo("Coherence.Brisk")]
[assembly: InternalsVisibleTo("Coherence.Brook")]
[assembly: InternalsVisibleTo("Coherence.Core")]
[assembly: InternalsVisibleTo("Coherence.Runtime")]
[assembly: InternalsVisibleTo("Coherence.Simulator")]
[assembly: InternalsVisibleTo("Coherence.UI")]
[assembly: InternalsVisibleTo("Coherence")]
[assembly: InternalsVisibleTo("Coherence.IntegrationTests")]
[assembly: InternalsVisibleTo("Coherence.Tests")]
[assembly: InternalsVisibleTo("Coherence.RSL.ReplicationManager")]
[assembly: InternalsVisibleTo("Coherence.RSL.Brisk")]
[assembly: InternalsVisibleTo("Coherence.RSL.EntityManager")]
[assembly: InternalsVisibleTo("Coherence.RSL.Transport")]
[assembly: InternalsVisibleTo("Coherence.Common.Tests")]
[assembly: InternalsVisibleTo("Coherence.Transport.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
[assembly: InternalsVisibleTo("Coherence.Runtime.Tests")]
[assembly: InternalsVisibleTo("Coherence.Serializer")]
[assembly: InternalsVisibleTo("Coherence.Toolkit.Tests")]
